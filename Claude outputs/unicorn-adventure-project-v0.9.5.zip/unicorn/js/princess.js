/* Princess Starla: the magical princess who lives in Starlight Castle. She waits by the keep door, skips over to say hello
   when a unicorn rides up, asks for a ride and hops onto the saddle. She rides along (leaning into turns, hair
   streaming, arms up on jumps, giggling, twirling her star wand), and hops off when you stop at the castle.
   No buttons: it all happens by riding up to her and standing still for a moment.

   She is built from simple toon shapes like everything else. While riding she is parented to the unicorn's saddle, so
   she follows every bob, pitch, squash and size change of the unicorn rig for free. */
(function () {
  const UA = window.UA,
    C = UA.C,
    T = THREE,
    V3 = T.Vector3;
  const Pr = (UA.Princess = { built: false, state: 'wait', riding: false });
  const TAU = Math.PI * 2;
  const SEAT = new V3(0, 2.5, 0.02); // where she sits, in the saddle's space
  const _v = new V3(),
    _w = new V3(),
    _q = new V3();

  /* ---------- the model ---------- */
  const SKIN = 0xffdcc6,
    HAIR = 0xffc93c,
    HAIR2 = 0xffe27a,
    DRESS = 0xff93c8,
    DRESS2 = 0xffc4e0,
    LILAC = 0xb394ff,
    GOLD = 0xffd45e;
  const M = (c, e) => UA.mat(c, e);
  const gem = (c, k) => UA.addGlow(new T.MeshToonMaterial({ color: c, gradientMap: UA.gradient, emissive: c, emissiveIntensity: 0.6 }), k || 1.4);

  /* Merge a rigid part's primitives into one to three vertex-coloured meshes (plain / glossy hair / glowing gold), so
     the whole princess costs a few dozen draw calls instead of a few hundred. Only direct mesh children are merged;
     child groups (arms, head, locks...) stay separate so they can still move. */
  let MATS = null,
    HAIRMAT = null;
  function bake(g) {
    if (!MATS) {
      const mk = () => new T.MeshToonMaterial({ vertexColors: true, gradientMap: UA.gradient });
      MATS = { toon: mk(), hair: UA.Cartoon && UA.Cartoon.gloss ? UA.Cartoon.gloss(mk()) : mk(), glow: UA.addGlow(mk(), 1.4) };
    }
    const lists = { toon: [], hair: [], glow: [] };
    const kill = [];
    g.children.forEach((m) => {
      if (!m.isMesh || m.userData.keep) return;
      m.updateMatrix();
      const mat = m.material;
      const kind = mat === HAIRMAT ? 'hair' : mat.emissive && mat.emissive.getHex() !== 0 ? 'glow' : 'toon';
      lists[kind].push({ geo: m.geometry, color: mat.color.getHex(), matrix: m.matrix.clone() });
      kill.push(m);
    });
    kill.forEach((m) => g.remove(m));
    for (const k in lists) if (lists[k].length) g.add(new T.Mesh(UA.mergeGeos(lists[k]), MATS[k]));
    return g;
  }

  function buildModel() {
    const B = UA.ball,
      CY = UA.cyl;
    const root = new T.Group();
    const hips = new T.Group();
    root.add(hips);
    const torso = new T.Group();
    hips.add(torso);

    // legs and shoes
    const legs = [-1, 1].map((s) => {
      const g = new T.Group();
      g.position.set(s * 0.13, -0.05, 0);
      g.add(CY(0.06, 0.55, M(SKIN), 0, -0.3, 0));
      g.add(B(0.1, M(LILAC), 1, 0.7, 1.55, 0, -0.62, 0.05));
      g.add(B(0.045, M(GOLD, GOLD), 1, 1, 1, 0, -0.6, 0.17, true));
      bake(g);
      hips.add(g);
      return g;
    });

    // the gown: a lathe (profile runs bottom to top so the faces point outwards)
    const prof = [
      [0.72, -0.62],
      [0.7, -0.55],
      [0.62, -0.42],
      [0.5, -0.27],
      [0.38, -0.13],
      [0.27, -0.02],
      [0.22, 0.05],
      [0.0, 0.05],
    ].map((p) => new T.Vector2(p[0], p[1]));
    const skirt = new T.Group();
    skirt.position.y = 0.02;
    const sk = new T.Mesh(new T.LatheGeometry(prof, 22), M(DRESS));
    skirt.add(sk);
    const under = new T.Mesh(new T.LatheGeometry(prof.map((p) => new T.Vector2(p.x * 1.0, p.y * 1.0)), 22), M(0xffffff));
    under.scale.set(1.06, 0.18, 1.06);
    under.position.y = -0.5;
    skirt.add(under);
    const hem = new T.Mesh(new T.TorusGeometry(0.705, 0.045, 6, 28).rotateX(Math.PI / 2), M(0xfff4fa));
    hem.position.y = -0.585;
    skirt.add(hem);
    // little gold stars on the gown
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU + 0.3,
        y = -0.3 - (i % 2) * 0.16;
      const r = 0.38 + (-y - 0.1) * 0.62;
      const s = B(0.045, M(GOLD, GOLD), 1, 1.3, 0.5, Math.cos(a) * r, y, Math.sin(a) * r, true);
      s.rotation.y = -a;
      skirt.add(s);
    }
    bake(skirt);
    hips.add(skirt);

    // bodice, sash, bow
    torso.add(CY(0.2, 0.46, M(DRESS2), 0, 0.26, 0));
    torso.add(B(0.235, M(DRESS2), 1, 0.85, 0.82, 0, 0.5, 0));
    const sash = new T.Mesh(new T.TorusGeometry(0.205, 0.05, 6, 20).rotateX(Math.PI / 2), M(LILAC));
    sash.position.y = 0.06;
    torso.add(sash);
    torso.add(B(0.08, M(LILAC), 1.5, 0.8, 0.8, -0.1, 0.1, -0.22, true));
    torso.add(B(0.08, M(LILAC), 1.5, 0.8, 0.8, 0.1, 0.1, -0.22, true));
    torso.add(B(0.05, M(GOLD, GOLD), 1, 1, 1, 0, 0.1, -0.22, true));
    torso.add(B(0.05, gem(0xff6fa8), 1, 1, 0.6, 0, 0.42, 0.23, true)); // brooch
    torso.add(CY(0.065, 0.14, M(SKIN), 0, 0.64, 0));
    bake(torso);

    // arms: sleeve puff, arm, hand
    const arms = [-1, 1].map((s) => {
      const g = new T.Group();
      g.position.set(s * 0.29, 0.52, 0);
      g.add(B(0.17, M(DRESS), 1, 1, 1, 0, 0, 0, true));
      const cuff = new T.Mesh(new T.TorusGeometry(0.09, 0.03, 5, 12).rotateX(Math.PI / 2), M(0xfff4fa));
      cuff.position.y = -0.14;
      g.add(cuff);
      g.add(CY(0.052, 0.4, M(SKIN), 0, -0.3, 0));
      g.add(B(0.07, M(SKIN), 1, 1, 1, 0, -0.52, 0, true));
      bake(g);
      torso.add(g);
      return g;
    });

    // her star wand, in the right hand (arms[0])
    const wand = new T.Group();
    wand.position.set(0, -0.52, 0);
    wand.rotation.x = 0.8;
    wand.add(CY(0.016, 0.95, M(0xfff4fa), 0, 0.4, 0));
    wand.add(B(0.03, M(LILAC), 1, 1, 1, 0, -0.06, 0, true));
    bake(wand);
    const star = new T.Mesh(new T.OctahedronGeometry(0.12, 0), gem(GOLD, 1.6));
    star.scale.set(1, 1.35, 0.45);
    star.position.y = 0.95;
    star.userData.noOutline = true;
    wand.add(star);
    const halo = new T.Sprite(new T.SpriteMaterial({ map: UA.radialTexture('rgba(255,236,160,1)', 'rgba(255,236,160,0)', 64), blending: T.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.8, fog: false }));
    halo.scale.set(0.9, 0.9, 1);
    halo.position.y = 0.95;
    wand.add(halo);
    arms[0].add(wand);

    // head
    const head = new T.Group();
    head.position.y = 1.1;
    torso.add(head);
    head.add(B(0.5, M(SKIN), 1.02, 0.96, 1, 0, 0, 0));
    // eyes: big, dark, two sparkles each
    const eyes = [-1, 1].map((s) => {
      const g = new T.Group();
      g.position.set(s * 0.19, -0.03, 0.452);
      g.add(B(0.1, M(0x3b2a6e), 1, 1.38, 0.5, 0, 0, 0));
      g.add(B(0.036, M(0xffffff), 1, 1, 0.5, s * -0.025, 0.06, 0.045, true));
      g.add(B(0.02, M(0xffffff), 1, 1, 0.5, s * 0.03, -0.045, 0.045, true));
      bake(g);
      head.add(g);
      return g;
    });
    [-1, 1].forEach((s) => {
      const b = B(0.075, M(0xb8802a), 1, 0.26, 0.3, s * 0.19, 0.16, 0.44, true);
      b.rotation.z = s * -0.22;
      head.add(b);
      head.add(B(0.1, M(0xff9fb4), 1.2, 0.7, 0.3, s * 0.3, -0.15, 0.37, true));
    });
    head.add(B(0.028, M(0xf2b8a0), 1, 1, 1, 0, -0.09, 0.495, true));
    const smile = new T.Mesh(new T.TorusGeometry(0.07, 0.016, 5, 12, Math.PI).rotateZ(Math.PI), M(0xb04a7a));
    smile.position.set(0, -0.17, 0.462);
    head.add(smile);

    // hair: a golden cap with a fringe, side locks and long locks down the back (they swing)
    const hairMat = (HAIRMAT = new T.MeshToonMaterial({ color: HAIR, gradientMap: UA.gradient }));
    head.add(B(0.555, hairMat, 1.04, 1.0, 1, 0, 0.05, -0.07));
    for (let i = 0; i < 7; i++) {
      const x = -0.33 + i * 0.11;
      const f = B(0.115, hairMat, 1, 1.25, 0.8, x, 0.3 - Math.abs(x) * 0.28, 0.4 - Math.abs(x) * 0.15, true);
      f.rotation.z = -x * 1.1;
      head.add(f);
    }
    [-1, 1].forEach((s) => head.add(B(0.14, hairMat, 0.9, 2.3, 0.9, s * 0.5, -0.17, -0.06, true)));
    const locks = [-0.27, 0, 0.27].map((x, i) => {
      const g = new T.Group();
      g.position.set(x, 0.05, -0.44);
      g.add(B(0.2, hairMat, 1, 2.7, 0.9, 0, -0.5, 0, true));
      g.add(B(0.14, M(HAIR2), 1, 2.4, 0.8, 0, -0.62, 0.0, true));
      bake(g);
      head.add(g);
      return g;
    });
    const bow = new T.Group();
    bow.position.set(0, -0.14, -0.5);
    bow.add(B(0.09, M(0xff6fa8), 1.7, 1, 0.6, -0.1, 0, 0, true));
    bow.add(B(0.09, M(0xff6fa8), 1.7, 1, 0.6, 0.1, 0, 0, true));
    bow.add(B(0.05, M(GOLD, GOLD), 1, 1, 1, 0, 0, 0.03, true));
    bake(bow);
    head.add(bow);

    // crown
    const crown = new T.Group();
    crown.position.set(0, 0.49, 0.02);
    crown.rotation.x = -0.2;
    crown.add(CY(0.37, 0.12, M(GOLD, GOLD), 0, 0, 0));
    const gems = [0xff6fa8, 0x7fc8ff, 0x8fe8c0, 0xb394ff, 0xff9ac4];
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * TAU + Math.PI / 2;
      const c = UA.cone(0.065, 0.24, M(GOLD, GOLD), Math.cos(a) * 0.35, 0.17, Math.sin(a) * 0.35);
      crown.add(c);
      crown.add(B(0.05, gem(gems[i], 1.6), 1, 1, 1, Math.cos(a) * 0.35, 0.3, Math.sin(a) * 0.35, true));
    }
    crown.add(B(0.07, gem(0xff6fa8, 1.6), 1, 1.1, 0.7, 0, 0, 0.375, true));
    bake(crown);
    head.add(crown);
    bake(head);

    return { root, hips, torso, skirt, legs, arms, wand, star, halo, head, eyes, locks, bow, ph: 0, blink: 0, blinkT: 2 };
  }

  /* ---------- posing ---------- */
  // p: skip (0..1 walking/skipping), sit, wave (left arm), twirl (wand arm), air (arms up, legs tucked), wind (hair streaming),
  // curtsy (0..1 over the move), lean (extra roll), look (head yaw), spd
  function pose(S, dt, t, p) {
    S.ph += dt * (8 + p.skip * 3);
    const ph = S.ph;
    const ease = (cur, tar, k) => UA.damp(cur, tar, k, dt);
    const W = S.w || (S.w = { sit: 0, air: 0, wave: 0, twirl: 0, lean: 0, look: 0, wind: 0, skip: 0 });
    W.sit = ease(W.sit, p.sit, 12);
    W.air = ease(W.air, p.air, 14);
    W.wave = ease(W.wave, p.wave, 10);
    W.twirl = ease(W.twirl, p.twirl, 10);
    W.lean = ease(W.lean, p.lean, 6);
    W.look = ease(W.look, p.look, 9);
    W.wind = ease(W.wind, p.wind, 5);
    W.skip = ease(W.skip, p.skip, 10);
    const sk = W.skip * (1 - W.sit) * (1 - W.air);
    const dip = Math.sin(Math.PI * UA.clamp(p.curtsy, 0, 1));

    // hips: standing height, down onto the saddle when sitting; bounce when skipping
    const idle = Math.sin(t * 2.1) * 0.012;
    S.hips.position.y = UA.lerp(0.72, 0.19, W.sit) + Math.abs(Math.sin(ph)) * 0.15 * sk + idle - dip * 0.2;
    S.torso.rotation.z = W.lean + Math.sin(t * 1.3) * 0.03 * (1 - W.sit) + Math.sin(ph) * 0.05 * sk;
    S.torso.rotation.x = dip * 0.32 + W.sit * 0.05 + sk * 0.06;
    S.torso.rotation.y = Math.sin(ph) * 0.1 * sk;
    // legs: swing when skipping, tuck in the air, out to the sides when sitting
    S.legs.forEach((leg, i) => {
      const s = i ? 1 : -1;
      leg.rotation.x = Math.sin(ph + i * Math.PI) * 0.95 * sk - W.air * 0.9 - W.sit * 0.3;
      leg.rotation.z = s * (W.sit * 0.95 + W.air * 0.2);
    });
    // gown: flares over the saddle, flutters in the air
    S.skirt.scale.set(1 + W.sit * 0.38 + dip * 0.15 + W.air * 0.12, 1 - W.air * 0.22, 1 + W.sit * 0.22 + dip * 0.15 + W.air * 0.12);
    S.skirt.rotation.z = Math.sin(ph + 1) * 0.07 * sk;
    S.skirt.rotation.x = -W.wind * 0.12;
    // arms
    const armR = S.arms[0],
      armL = S.arms[1];
    const swing = Math.sin(ph) * 0.8 * sk;
    let lx = swing,
      lz = 0.05,
      rx = -swing,
      rz = -0.05;
    // riding: hands forward on the mane
    lx = UA.lerp(lx, -0.95, W.sit);
    rx = UA.lerp(rx, -0.95, W.sit);
    lz = UA.lerp(lz, 0.2, W.sit);
    rz = UA.lerp(rz, -0.2, W.sit);
    // in the air: both arms up, flapping with joy
    const flap = Math.sin(t * 12) * 0.25;
    lx = UA.lerp(lx, -0.25, W.air);
    rx = UA.lerp(rx, -0.25, W.air);
    lz = UA.lerp(lz, 2.5 + flap, W.air);
    rz = UA.lerp(rz, -2.5 - flap, W.air);
    // waving hello with the left arm, wand twirl with the right
    lx = UA.lerp(lx, -0.15, W.wave);
    lz = UA.lerp(lz, 2.55 + Math.sin(t * 10) * 0.32, W.wave);
    rx = UA.lerp(rx, -0.55, W.twirl);
    rz = UA.lerp(rz, -1.7, W.twirl);
    armL.rotation.set(lx, 0, lz);
    armR.rotation.set(rx, 0, rz);
    S.wand.rotation.set(0.8 - W.twirl * 0.2, 0, Math.sin(t * 15) * 0.7 * W.twirl);
    const pulse = 1 + Math.sin(t * 6) * 0.08 + W.twirl * 0.3;
    S.halo.scale.set(0.9 * pulse, 0.9 * pulse, 1);
    S.star.rotation.y = t * 2;

    // head: looks where she is looking, tilts when she is happy, blinks
    S.head.rotation.y = W.look;
    S.head.rotation.x = -dip * 0.1 + Math.sin(t * 0.9) * 0.02 - W.wind * 0.08;
    S.head.rotation.z = Math.sin(t * 1.1) * 0.04 + W.wave * 0.06 + W.lean * 0.5;
    S.blinkT -= dt;
    if (S.blinkT <= 0) {
      S.blink = 0.14;
      S.blinkT = 2 + Math.random() * 3;
    }
    S.blink = Math.max(0, S.blink - dt);
    const eyeY = S.blink > 0 ? 0.12 : 1;
    S.eyes.forEach((e) => (e.scale.y = eyeY));
    // long locks swing, stream back with speed
    S.locks.forEach((l, i) => {
      l.rotation.x = 0.08 + W.wind * (0.95 + i * 0.05) + Math.sin(t * 2.2 + i * 1.3) * 0.07 + Math.sin(ph + i) * 0.14 * sk + W.air * 0.2;
      l.rotation.z = Math.sin(t * 1.7 + i) * 0.05 + (i - 1) * 0.04 * W.wind - W.lean * 0.6;
    });
    S.bow.rotation.z = Math.sin(t * 3) * 0.1;
  }

  /* ---------- behaviour ---------- */
  const LINES = {
    wow: ['Wheee!', 'This is so fun!', 'I love riding!', 'What a lovely day!', 'Wow, so fast!', 'Yippee!'],
    fast: ['Faster, faster!', 'Whoosh!', 'Hold on tight!', 'Zoom zoom zoom!'],
    air: ['Wheee!', 'We are flying!', 'Wow, up we go!'],
    poop: ['Hee hee! Glitter!', 'Oh my! So sparkly!', 'Hehehe! Pretty sparkles!'],
    friend: { bunny: 'Hello, little bunny!', sheep: 'Hello, fluffy sheep!', fox: 'Hello, Mr. Fox!', dragon: 'Hello, little dragon!' },
  };
  const rnd = (a) => a[(Math.random() * a.length) | 0];
  const home = () => UA.Realm.toWorld(UA.Realm.PRINCESS_HOME.lx, UA.Realm.PRINCESS_HOME.lz);
  const dist2 = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);

  function say(text, giggle) {
    const S = Pr.S;
    S.head.getWorldPosition(_v);
    Pr.proxy.pos.set(_v.x, _v.y - 2.0, _v.z);
    UA.UI.say(Pr.proxy, text);
    Pr.lineCd = 5;
    if (giggle && UA.Audio.giggle) UA.Audio.giggle();
  }
  function sparkle(n, spread) {
    const S = Pr.S;
    S.star.getWorldPosition(_w);
    UA.FX.sparkles(_w, n || 4, undefined, spread || 0.6, 0.6);
  }
  // face a point, turning smoothly
  function faceTo(x, z, dt, rate) {
    const R = Pr.S.root;
    const want = Math.atan2(x - R.position.x, z - R.position.z);
    R.rotation.y += UA.clamp(UA.angleDiff(R.rotation.y, want), -(rate || 8) * dt, (rate || 8) * dt);
  }
  // walk (skip) toward a spot; returns the distance left. Sets Pr.moved when she really made progress.
  // If the way is blocked (the fountain, a column) she sidesteps around it instead of pushing into it.
  function skipTo(x, z, dt, speed) {
    const R = Pr.S.root;
    const dx = x - R.position.x,
      dz = z - R.position.z;
    const d = Math.hypot(dx, dz);
    Pr.moved = false;
    if (d > 0.05) {
      const ux = dx / d,
        uz = dz / d;
      const st = Math.min(d, speed * dt);
      const side = Pr.side || 1;
      let best = null;
      for (const a of [0, side * 0.85, -side * 0.85, side * 1.6, -side * 1.6]) {
        const ca = Math.cos(a),
          sa = Math.sin(a);
        const dirx = ux * ca - uz * sa,
          dirz = ux * sa + uz * ca;
        _q.set(R.position.x + dirx * st, 0, R.position.z + dirz * st);
        // stay inside the castle grounds
        const lx = UA.clamp(_q.x - UA.REALM.x, -30, 30),
          lz = UA.clamp(_q.z - UA.REALM.z, -25, 8);
        _q.x = UA.REALM.x + lx;
        _q.z = UA.REALM.z + lz;
        UA.World.resolve(_q, 0.7);
        const mx = _q.x - R.position.x,
          mz = _q.z - R.position.z;
        const prog = (mx * ux + mz * uz) / st;
        const disp = Math.hypot(mx, mz) / st;
        // straight on if it works; otherwise any sidestep that really gets her somewhere (sliding round the fountain)
        if (disp > 0.5 && prog > (a === 0 ? 0.45 : -0.1)) {
          best = { x: _q.x, z: _q.z, a, prog, disp, score: 9 };
          break;
        }
        const score = prog + 0.3 * disp;
        if (!best || score > best.score) best = { x: _q.x, z: _q.z, a, prog, disp, score };
      }
      if (best && best.a !== 0) Pr.side = best.a > 0 ? 1 : -1;
      if (best && best.disp > 0.2) {
        const mx = best.x - R.position.x,
          mz = best.z - R.position.z;
        faceTo(R.position.x + mx, R.position.z + mz, dt, 12);
        R.position.x = best.x;
        R.position.z = best.z;
        Pr.moved = true;
      } else faceTo(x, z, dt, 10);
      R.position.y = UA.World.groundAt(R.position.x, R.position.z);
    }
    return d;
  }
  function setState(s) {
    Pr.state = s;
    Pr.t = 0;
    Pr.step = -1; // the intro's line counter starts over every time
  }
  function toHome(sparkles) {
    const h = home();
    const R = Pr.S.root;
    if (R.parent && R.parent !== Pr.scene) {
      R.parent.remove(R);
      Pr.scene.add(R);
    }
    R.position.copy(h);
    R.rotation.set(0, 0, 0);
    R.scale.setScalar(Pr.scale);
    if (sparkles && UA.Realm.inRealm) UA.FX.burst(_v.set(h.x, h.y + 1.6, h.z), 18);
    Pr.riding = false;
    setState('wait');
  }

  Pr.build = function (scene) {
    if (Pr.built) return;
    Pr.built = true;
    Pr.scene = scene;
    Pr.scale = 0.9; // a little smaller than the model's natural size, so she sits nicely on the saddle
    const S = (Pr.S = buildModel());
    S.root.scale.setScalar(Pr.scale);
    scene.add(S.root);
    S.root.visible = false;
    Pr.proxy = { pos: new V3(), scale: 1 };
    Pr.cool = 0;
    Pr.lineCd = 0;
    Pr.rideT = 0;
    Pr.stillT = 0;
    Pr.hopT = 0;
    Pr.curtsyT = 9;
    Pr.wandCd = 12;
    Pr.lastPoops = 0;
    Pr.wasGrounded = true;
    Pr.fastT = 0;
    Pr.jumped = false;
    toHome(false);
    if (UA.Outline && UA.Outline.apply) UA.Outline.apply(S.root);
  };

  // called by realm.js when the unicorn goes through a portal
  Pr.onPortal = function (uni) {
    if (!Pr.built) return;
    if (Pr.state === 'ride') {
      Pr.lineCd = 0;
      say(UA.Realm.inRealm ? rnd(['Home sweet castle!', 'Look, we are home!']) : rnd(['Ooh! What a pretty place!', 'Wow! Where are we?']), true);
    } else if (Pr.state === 'hop' || Pr.state === 'drop') {
      if (Pr.state === 'hop') mount(uni);
      else toHome(false);
    } else if (Pr.state !== 'wait') {
      toHome(false);
    }
    Pr.cool = Math.max(Pr.cool, 3);
  };

  function mount(uni) {
    const R = Pr.S.root;
    if (R.parent) R.parent.remove(R);
    uni.P.saddle.add(R);
    R.position.copy(SEAT);
    R.rotation.set(0, 0, 0);
    R.scale.setScalar(Pr.scale);
    Pr.riding = true;
    Pr.rideT = 0;
    Pr.stillT = 0;
    Pr.fastT = 0;
    Pr.wandCd = 10;
    Pr.lineCd = 3;
    Pr.lastPoops = UA.GlitterPoop ? UA.GlitterPoop.total : 0;
    setState('ride');
    UA.FX.burst(_v.set(uni.pos.x, uni.pos.y + 3.2 * uni.size, uni.pos.z), 22);
    UA.FX.hearts(_v, 5);
    if (UA.Audio.hello) UA.Audio.hello();
    if (!UA.state.princessRode) {
      UA.state.princessRode = true;
      UA.UI.toast('Princess Starla is riding with you!<small>Stop for a moment at the castle and she will hop off</small>', 4600);
      if (UA.save) UA.save();
    }
  }

  function dismount(uni, toGround) {
    const R = Pr.S.root;
    // take her off the saddle at its current place in the world
    uni.P.saddle.localToWorld(_v.copy(SEAT));
    uni.P.saddle.remove(R);
    Pr.scene.add(R);
    R.position.copy(_v);
    R.rotation.set(0, uni.yaw, 0);
    R.scale.setScalar(Pr.scale * uni.size);
    Pr.hopFrom = _v.clone();
    // land beside the unicorn, on her right
    const side = uni.yaw - Math.PI / 2;
    Pr.hopTo = new V3(uni.pos.x + Math.sin(side) * 3.0, 0, uni.pos.z + Math.cos(side) * 3.0);
    Pr.hopTo.y = UA.World.groundAt(Pr.hopTo.x, Pr.hopTo.z);
    Pr.hopYaw0 = uni.yaw;
    Pr.hopYaw1 = uni.yaw + Math.PI * 0.9;
    Pr.riding = false;
    setState('drop');
  }

  Pr.update = function (dt, t, uni, ctx) {
    if (!Pr.built) return;
    const S = Pr.S,
      Realm = UA.Realm;
    const riding = Pr.state === 'ride';
    const visible = Realm.inRealm || riding || Pr.state === 'hop' || Pr.state === 'drop' || Pr.state === 'poof';
    S.root.visible = visible;
    if (!visible) {
      if (Pr.state !== 'wait') toHome(false);
      return;
    }
    Pr.cool = Math.max(0, Pr.cool - dt);
    Pr.lineCd = Math.max(0, Pr.lineCd - dt);
    Pr.t += dt;
    Pr.curtsyT += dt;
    const R = S.root;
    const h = home();
    const p = { skip: 0, sit: 0, wave: 0, twirl: 0, air: 0, wind: 0, lean: 0, look: 0, curtsy: Pr.curtsyT < 0.9 ? Pr.curtsyT / 0.9 : 1 };
    const du = dist2(uni.pos, R.position); // only meaningful while she is on the ground

    if (Pr.state === 'wait') {
      // by the keep door, glancing at the unicorn and waving when she is near
      const dHome = dist2(uni.pos, h);
      const dNow = dist2(uni.pos, R.position);
      const away = dist2(R.position, h) > 1.2;
      if (away) {
        skipTo(h.x, h.z, dt, 6);
        p.skip = Pr.moved ? 1 : 0;
      } else {
        faceTo(dNow < 40 ? uni.pos.x : h.x, dNow < 40 ? uni.pos.z : h.z + 10, dt, 6);
      }
      p.wave = dNow < 34 && dNow > 6 ? 1 : 0;
      p.look = dNow < 30 ? UA.clamp(UA.angleDiff(R.rotation.y, Math.atan2(uni.pos.x - R.position.x, uni.pos.z - R.position.z)), -0.7, 0.7) : 0;
      // a twinkle from the wand now and then
      Pr.wandCd -= dt;
      if (Pr.wandCd <= 0) {
        Pr.wandCd = 6 + Math.random() * 6;
        Pr.twirlT = 1.2;
      }
      Pr.twirlT = Math.max(0, (Pr.twirlT || 0) - dt);
      p.twirl = Pr.twirlT > 0 ? 1 : 0;
      if (Pr.twirlT > 0 && Math.random() < dt * 14) sparkle(2, 0.5);
      // somebody is coming: go and say hello
      if (Pr.cool <= 0 && !away && uni.grounded && uni.size < 2.6 && dNow < 34 && Realm.inRealm) {
        if (!UA.state.princessMet) say('Yoo-hoo! A unicorn!', true);
        else say('Hello again, ' + (UA.state.name || 'Sparkle') + '!', true);
        setState('come');
      } else if (Pr.cool <= 0 && away && dNow < 34) {
        setState('come');
      }
    } else if (Pr.state === 'come') {
      // skip over to the unicorn and stop a few steps away
      const dx = R.position.x - uni.pos.x,
        dz = R.position.z - uni.pos.z;
      const d = Math.hypot(dx, dz) || 1;
      const tx = uni.pos.x + (dx / d) * 3.5,
        tz = uni.pos.z + (dz / d) * 3.5;
      skipTo(tx, tz, dt, 8.5);
      p.skip = Pr.moved ? 1 : 0;
      p.wave = d < 12 || !Pr.moved ? 1 : 0;
      if (d < 4.4) {
        setState('intro');
      } else if (d > 48 || !Realm.inRealm) {
        Pr.cool = 5;
        setState('wait');
      }
    } else if (Pr.state === 'intro') {
      // greet, curtsy, ask for a ride
      faceTo(uni.pos.x, uni.pos.z, dt, 9);
      p.look = UA.clamp(UA.angleDiff(R.rotation.y, Math.atan2(uni.pos.x - R.position.x, uni.pos.z - R.position.z)), -0.6, 0.6);
      const first = !UA.state.princessMet;
      const k = Pr.t;
      const step = first ? [0, 2.7, 5.4, 7.6] : [0, 2.2, 4.0];
      const want = step.filter((s) => k >= s).length - 1;
      while (Pr.step < want) {
        Pr.step++;
        if (first) {
          if (Pr.step === 0) {
            say("Hello! I'm Princess Starla!", true);
            if (UA.Audio.hello) UA.Audio.hello();
          } else if (Pr.step === 1) {
            say('Welcome to Starlight Castle!');
            Pr.curtsyT = 0;
          } else if (Pr.step === 2) say('May I ride with you?');
        } else {
          if (Pr.step === 0) {
            say('Welcome back, ' + (UA.state.name || 'Sparkle') + '!', true);
            Pr.curtsyT = 0;
          } else if (Pr.step === 1) say('Shall we go for a ride?');
        }
      }
      p.wave = k < 2.4 ? 1 : 0;
      if (first && k > 5 && k < 7.4) p.twirl = 0;
      const readyT = first ? 7.6 : 4.0;
      if (k >= readyT) {
        if (du < 9 && uni.grounded && uni.speed < 6 && !uni.gliding) {
          UA.state.princessMet = true;
          if (UA.save) UA.save();
          Pr.hopFrom = R.position.clone();
          setState('hop');
          Pr.hopYaw0 = R.rotation.y;
          UA.Audio.jump();
        } else if (du > 14 || uni.speed > 9) {
          // she asked, but they rode off: wave goodbye
          say('Come back soon!');
          Pr.cool = 8;
          setState('wait');
        }
      } else if (du > 20) {
        say('Wait for me!');
        setState('come');
      }
      // she is not far when they are close: keep her facing and bobbing happily
      p.skip = 0;
    } else if (Pr.state === 'hop') {
      // a twirling leap onto the saddle
      const k = UA.clamp(Pr.t / 0.95, 0, 1);
      uni.P.saddle.localToWorld(_q.copy(SEAT));
      _v.lerpVectors(Pr.hopFrom, _q, k * k * (3 - 2 * k));
      _v.y += Math.sin(Math.PI * k) * 2.6;
      R.position.copy(_v);
      R.rotation.y = Pr.hopYaw0 + UA.angleDiff(Pr.hopYaw0, uni.yaw) * k + k * TAU;
      R.scale.setScalar(Pr.scale * UA.lerp(1, uni.size, k));
      p.air = Math.sin(Math.PI * Math.min(1, k * 1.15));
      p.sit = k > 0.8 ? (k - 0.8) / 0.2 : 0;
      p.wave = 0;
      if (Math.random() < dt * 30) UA.FX.sparkles(_v, 1, undefined, 0.5, 0.2);
      if (k >= 1) {
        mount(uni);
        say('Wheee! Off we go!', true);
      }
    } else if (Pr.state === 'ride') {
      rideUpdate(dt, t, uni, ctx, p);
    } else if (Pr.state === 'drop') {
      const k = UA.clamp(Pr.t / 0.85, 0, 1);
      _v.lerpVectors(Pr.hopFrom, Pr.hopTo, k);
      _v.y += Math.sin(Math.PI * k) * 2.2;
      R.position.copy(_v);
      R.rotation.y = Pr.hopYaw0 + (Pr.hopYaw1 - Pr.hopYaw0) * k;
      R.scale.setScalar(Pr.scale * UA.lerp(uni.size, 1, k));
      p.air = Math.sin(Math.PI * k);
      p.sit = 1 - Math.min(1, k * 3);
      if (k >= 1) {
        R.position.copy(Pr.hopTo);
        R.scale.setScalar(Pr.scale);
        UA.FX.puff(R.position, 6, 0xfff4fb);
        Pr.cool = 22;
        Pr.curtsyT = 0;
        if (Realm.inRealm && dist2(R.position, h) < 30) {
          say('Thank you for the lovely ride!', true);
          setState('wait');
        } else {
          // far from the castle (or at the unicorn's home): a twinkle and she is back at the castle
          say('Thank you! Bye bye!', true);
          setState('poof');
        }
      }
    } else if (Pr.state === 'poof') {
      p.wave = 1;
      faceTo(uni.pos.x, uni.pos.z, dt, 8);
      if (Pr.t > 1.7) {
        UA.FX.burst(_v.set(R.position.x, R.position.y + 1.6, R.position.z), 26);
        UA.Audio.sparkle();
        toHome(false);
        Pr.cool = 12;
      }
    }

    // sparkle dust drifting off her wand in the world (not every frame)
    if (Pr.state !== 'wait' || p.twirl) pose(S, dt, t, p);
    else pose(S, dt, t, p);
    // keep the speech bubble's anchor on her head
    S.head.getWorldPosition(_v);
    Pr.proxy.pos.set(_v.x, _v.y - 2.0, _v.z);
  };

  function rideUpdate(dt, t, uni, ctx, p) {
    const S = Pr.S;
    Pr.rideT += dt;
    p.sit = 1;
    const spd = uni.speed;
    const spdFrac = UA.clamp(spd / 14, 0, 1);
    p.wind = spdFrac * 0.95 + (uni.gliding ? 0.5 : 0);
    p.lean = UA.clamp(-uni.yawRate * 0.022, -0.25, 0.25);
    p.look = UA.clamp(uni.yawRate * 0.035, -0.5, 0.5);
    const air = !uni.grounded && !uni.gliding && uni.pos.y - UA.World.groundAt(uni.pos.x, uni.pos.z) > 1.2;
    p.air = air || uni.gliding ? 1 : 0;
    // wand: twirl now and then, and when the unicorn casts magic
    Pr.wandCd -= dt;
    if (ctx && ctx.input && ctx.input.magic) Pr.wandCd = Math.min(Pr.wandCd, 0);
    if (Pr.wandCd <= 0) {
      Pr.wandCd = 14 + Math.random() * 10;
      Pr.twirlT = 1.4;
      // her sparkle makes nearby friends cheer
      if (UA.Creatures.nearest(uni, 10)) UA.Creatures.dazzle(uni.pos, 10);
      if (Pr.lineCd <= 0) say(rnd(['Sparkle sparkle!', 'A little magic!', 'Ta-da!']), true);
    }
    Pr.twirlT = Math.max(0, (Pr.twirlT || 0) - dt);
    p.twirl = Pr.twirlT > 0 && !p.air ? 1 : 0;
    if (Pr.twirlT > 0 && Math.random() < dt * 20) sparkle(2, 0.5);
    // things to say
    const jumpedNow = !uni.grounded && Pr.wasGrounded && uni.vy > 5;
    Pr.wasGrounded = uni.grounded;
    if (jumpedNow && Pr.lineCd <= 0 && Math.random() < 0.55) say(rnd(LINES.air), true);
    Pr.fastT = spd > 12 ? Pr.fastT + dt : 0;
    if (Pr.fastT > 3.2 && Pr.lineCd <= 0) {
      Pr.fastT = 0;
      say(rnd(LINES.fast));
    }
    if (UA.GlitterPoop && UA.GlitterPoop.total !== Pr.lastPoops) {
      Pr.lastPoops = UA.GlitterPoop.total;
      Pr.lineCd = 0;
      say(rnd(LINES.poop), true);
    }
    if (Pr.lineCd <= 0 && Pr.rideT > 5) {
      const near = UA.Creatures.nearest(uni, 9);
      if (near && near.bond === 0 && Math.random() < 0.5 && LINES.friend[near.type]) say(LINES.friend[near.type]);
      else if (Math.random() < dt * 0.12) say(rnd(LINES.wow), spd > 8);
    }
    // time to get off? she hops down when you stop for a moment (right away at the castle, after a longer pause elsewhere)
    Pr.stillT = spd < 0.8 && uni.grounded ? Pr.stillT + dt : 0;
    const dHome = dist2(uni.pos, home());
    const atCastle = UA.Realm.inRealm && dHome < 26;
    if (Pr.rideT > 14 && uni.grounded && ((atCastle && Pr.stillT > 2.4) || Pr.stillT > 8)) dismount(uni);
  }
})();
