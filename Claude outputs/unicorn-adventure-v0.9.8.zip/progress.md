# Unicorn Adventure - progress log

Open world 3D unicorn game for kids (ages 5 to 12). Browser based (Three.js). Runs by opening `index.html` (or the single-file build in `dist/`), with no server and no build step.

## How to play
- Open `dist/unicorn-adventure.html` (one self-contained file, about 1 MB) or `index.html` in a modern browser. Works offline.
- Keyboard: WASD / arrows move, Shift gallop, Space jump (press again in the air to flap, hold to glide), E pet / wish at the fountain / say hi to townsfolk, F feed, R play, Q or Enter horn magic, C cycle spell (or 1-4), N skip time of day, P dream ride (autopilot), ` show or hide the fps readout, B friends book, H help
- Mouse: drag to look around, wheel to zoom
- Touch (tablet/phone): left joystick, on-screen buttons, drag the scene to look
- Gamepad: left stick move, right stick camera, A jump, X magic, B pet, Y feed, LB play, RT gallop, d-pad right = spell, d-pad up = time
- Debug helpers: add `?autostart=1&coat=2&name=Alex&debug=1` to the URL. Also `hour=21&freeze=1` (time of day), `grass=0` (no grass), `keepgrass` (never auto-drop the grass on slow devices)

## Decisions (made with Alex)
- Ages 5-12, built on imagination and whimsy
- Look: Cotton-candy dreamland (soft pastels, rainbow skies, lollipop trees)
- Core loop: free exploration, befriend and collect creatures, small quests, mini-games
- Interactions: pet and feed, play together, sparkle magic from the horn
- Unicorn: gallop, jump, glide. Grows over time by unlocking gear
- World: one big seamless landscape
- Tech: Three.js r158 in the browser, keyboard + mouse + gamepad + touch controls
- Defaults chosen by me: single player, no fail states, no ads or online, progress saved locally

## Log
### Session 1 (Thu 5 Nov 2026)
**Foundation and world**
- Project set up, Three.js r158 vendored in `lib/` so the game works from file:// and offline. Classic script tags and one global `UA` namespace (no bundler)
- World: analytic height function (seamless terrain), vertex-colored toon terrain, 5 ponds, candy mountain ring at the edge, ~250 lollipop trees, giant mushrooms, ~4000 tulips, drifting clouds, rainbow arch landmark, gumdrop bushes (treat pickups that regrow after 30s)
- Four named regions with a toast when you cross in: Rose Grove, Minty Meadows, Lilac Hills, Sunny Glades (start area is Sparkle Meadow). Each has its own tree palette and ground tint
- Look: toon shading (4-step gradient), fog, sky dome, blob shadows, point-sprite particles (circles, sparkles, hearts)

**Unicorn**
- Procedural cartoon model (rainbow mane/tail, saddle pad, wings that open when gliding), gallop/trot gait, jump, flap, glide, slope alignment, water wading, rainbow trail when galloping/gliding, horn magic (burst, flowers sprout, nearby creatures dance)
- Camera: chase camera with drag-to-look, auto swing behind, zoom, speed FOV. Collides with tree crowns and mushroom caps: it lifts the pitch first, then pulls in if still blocked

**Creatures and quests**
- Species: Cloud Bunny, Gumdrop Dragon, Sparkle Fox, Cotton Sheep (30 total), each with its own behaviour (bunnies flee, foxes are curious, etc.). Wander, follow, play, dance, eat. Pet, feed, play. Up to 3 followers. Hearts per creature (0-3)
- Quests (one at a time, no failing, a yellow "!" floats over the giver): Find the baby bunnies (hide behind mushrooms, pink sparkle beacons), Feed the dragon three gumdrops, Catch the fox three times (tag). Rewards are treats and a best friend
- Unlocks: Flower Garland (2 friends), Star Clip (5), Sparkle Bow and Anklets (9)
- Mini-game: Rainbow Ring Run (8 rings that climb, so you need to glide)

**UI, audio, saving**
- HUD, speech bubbles, creature prompt (Pet/Feed/Play), friends book, start screen with live coat preview and name, touch controls, help
- Audio: synthesized sound effects and a gentle generative lullaby (no audio files)
- Save: localStorage (name, coat, treats, friends, quests, unlocked gear). All access is wrapped in try/catch

**Performance and robustness**
- Adaptive resolution: pixel ratio steps down if the frame rate stays low, and back up if it recovers
- Gamepad polling wrapped in try/catch (blocked in some embedded pages)
- Tree triangle budget reduced (secondary crown blobs use low detail). Roughly 520k triangles and 380-490 draw calls in the busiest view

**Testing (headless Chromium, SwiftShader, ~10 fps so game time runs slow)**
- No console errors in soak runs. Verified: movement, jump, flap, glide, pet, feed, play, magic, all three quests (babies and hungry completed, tag progressed), iPad touch layout, single-file build loading and rendering
- Not tested on real hardware (no GPU in the sandbox). First thing to check when you play: frame rate on the iPad

**Packaging**
- `build_single.py` bundles everything into `dist/unicorn-adventure.html` and `dist/unicorn-adventure.fragment.html` (the same page without html/head/body, used to publish it as a shareable web page)
- Run `python3 build_single.py` after any code change to refresh the single-file build

### Notes
- Three r155+ uses physical light units, so light intensities are about PI times the old values (hemisphere 2.15, sun 1.3). ShaderMaterials need `linearToOutputTexel` for correct colour
- Forward is +Z; `yaw` rotates +Z toward +X
- The three.min.js deprecation warning in the console is harmless (r158 UMD build)
- Link to Alex's computer dropped mid-session, so files were not written to his project folder (`Cartoon Kids Unicorn Adventure` under OneDrive/Programming). Everything is delivered as a zip and a playable page, and can be copied into the folder once the link is back

## Magic Update (v0.3)
Brainstormed 12 ideas, picked the ones that add a new *kind* of play and fit the cotton-candy tone. Ruled out anything with fail states, scary content or text-heavy puzzles. All of these are built and tested headlessly.

1. **Day/night with twilight glow** (`js/daynight.js`) - sky, light and fog shift through sunrise, day, sunset and night over a 10 minute day. Stars, an aurora, a sleepy moon, fireflies, glowing flowers/mushrooms, a glowing horn light. Wild creatures fall asleep at night (Zzz) and wake with a yawn when you come near; friends stay up. Shooting stars: cast magic under one to wish (+2 treats). `N` skips to the next phase (sunrise, day, sunset, starry night)
2. **Spell wheel** (`js/magic.js`) - Sparkle Burst, Bubble Float (creatures drift up in soap bubbles), Butterfly Swarm (glow moths at night), Rainbow Rain (little rain cloud, flower shower, a rainbow arch you can ride through for a speed boost). Unlocked by making friends. `C` cycles, `1-4` picks
3. **Bouncy mushrooms** (`js/wonders.js`) - land on a giant cap and go boing (squash and stretch). Chain them to reach high things
4. **Gear powers** (`js/unicorn.js`) - Flower Garland leaves a flower trail, Star Clip glides slower and shines, Bow and Anklets walk on water with rainbow ripples
5. **Fairy rings** - glowing mushroom rings in pairs; ride in and whoosh to the twin across the map
6. **Wishing fountain** - make a free wish (E; costs nothing since v0.9.5) for one of 9 wishes: flower shower, gumdrop rain, creature party, rainbow, starry night, giant unicorn, teeny unicorn, shooting stars, bubble party
7. **Rainbow Chimes** - eight musical stepping stones, plus the "copy the song" quest from Cotton Sheep (3 rounds of 3, 4 and 5 notes)
8. Rainbow arch speed boost

Fixes found while testing this round:
- The chime songs originally skipped pads (0, 2, 4), which is impossible to play by riding along a row. Songs are now step-wise (0-1-2, 3-2-1-0, 1-2-3-4-3), pads fire once when you step on (not while you stand), a wrong first note is ignored and a wrong later note replays the demo (never a fail)
- Particle sizes are capped to 16% of the screen height so a sparkle next to the camera cannot fill the view

## Visual upgrade (v0.4)
Asked for by Alex: better visuals at low GPU cost, varied grass, a nicer unicorn, sparkles while running.
- **Grass** (`js/grass.js`) - a ring of ~9,200 tufts that follows the unicorn, drawn in ONE draw call (about +55k triangles). Tufts come in four kinds (regular, thin tall wisps, fat short clumps, big shaggy tufts), pastel green tints with a few pink/lilac/buttercup ones, nudged toward the local region colour. Wind sway in the vertex shader, grass parts and lies down around the unicorn, shrinks to nothing at the edge so nothing pops. No grass in ponds, on beaches, high peaks, or under the fountain, chimes and fairy rings. CPU cost is only recycling the cells that scroll in. If a device is still under 26 fps at the lowest resolution for ~5 seconds the grass switches itself off (never in `debug` mode)
- **Unicorn** (`js/unicorn.js`) - coat shader with a soft pastel rim light and twinkling glitter (no extra draw calls); big glossy violet eyes with highlights and lashes; spiral striped horn with a twinkling star at the tip that flares when you cast; fuller mane and tail; fluffy coloured fetlock cuffs; a glowing star cutie mark on each flank. About 25 extra draw calls
- **Running sparkles** - on every footfall the hooves throw star glitter, and while galloping or gliding glitter drifts off the mane and tail and floats up. Stars twinkle (new `twinkle` option in `FX.emit`)

- **Dream ride** (`P`) - the unicorn wanders, gallops, hops, glides and casts magic on its own; steering or pressing P again takes over. For little ones who want to watch, and a handy way to soak-test on a real GPU
- **Frame-rate readout** - press the backtick key (`) any time to show fps, pixel ratio, whether the grass is on, draw calls and triangles

## Unicorn rework (v0.5, Thu 5 Nov 2026 evening)
Alex: "The unicorn model and running animations suck. Can you rework them", and asked whether additive blending with a blurred canvas circle makes sense for sparkles and magic (yes, see below). Later: the camera moved awkwardly in and out, especially when flying.
- **New body** (`js/unicorn_rig.js`, `js/unicorn.js`) - no more stacked balls. The torso, neck, head and legs are smooth lofted shells built from elliptical rings (`R.Loft`): barrel body with a deep chest and rounded haunches, an arched two-piece neck, a proper head with a pink muzzle patch, and tapered legs with knee and hock bumps, fluffy fetlock cuffs and flat gold hooves. About 5k triangles, all drawn with the same coat shader (rim light and glitter) as before
- **Real gaits** - walk (4 beats), trot (diagonal pairs), canter (3 beats) and gallop (4 beats with a flight phase), blended by speed (`GAITS` table in `unicorn.js`). Each hoof lands where the ground is moving under it (stride length = speed x stance time / stride rate), so there is no foot skating. Legs are solved with two-bone IK, so the knee and hock bend naturally and the hoof lands flat. Body height follows how many hooves are down, the spine arches when the legs gather and hollows when they stretch, the body curves into turns, the neck stretches and nods with the stride, tail carriage rises with speed. Jump, rise, fall and glide have their own leg poses (tucked, reaching, stretched out)
- **Flowing mane, forelock and tail** - 12 mane locks down the crest, two forelock curls and a fan of 9 tail locks, each a tapered tube that trails like hair (chain of points with inertia, pulled toward a hanging pose or streaming back when running, with a flutter). One draw call, simulated on the CPU (a few hundred points)
- **Footfall sparkles** now fire from the exact hoof that just landed, and the glitter drifts off real points on the mane and tail
- **Soft additive glow** (`js/effects.js`) - every sparkle, heart and rainbow-trail puff now has a second, larger, blurred halo drawn with additive blending (radial falloff in the shader, which is the same look as a blurred canvas texture without the texture fetch). It stays gentle by day and glows at dusk and night. The horn star is additive too. One extra draw call
- **Camera** - the camera now sits at a fixed offset from a smoothed focus point instead of trailing behind on its own spring (that spring is what made the distance pulse with every speed change and flap). While airborne the focus follows height slowly, the camera no longer gets pulled in by tree crowns when flying, the pitch search is slower, and the speed zoom is subtle (62 to 66 degrees) and driven by a smoothed speed
- **Camera, final structure** - the camera keeps a smoothed *offset* from a smoothed focus point rather than chasing on its own spring. Measured on a scripted gallop-and-fly route: standard deviation of the camera distance fell 46%, and the fastest in/out zoom fell from 24.6 to about 10 units per second. The height lag is soft-capped (tanh), the xz focus is locked tight to the unicorn, the obstacle pull-in has a floor (the camera is never pulled closer than 70% of the way), and tree crowns are ignored while flying
- **Trail and glitter toned down** - the rainbow trail and mane glitter were hiding the unicorn from the rear camera. Trail puffs are smaller and softer (size 0.55, glow 0.3), glitter is thinner (interval 0.075 minus 0.03 times the speed fraction, size 0.36-0.86), the Star Clip glide stars are smaller, and every particle fades out as it passes within 2 to 6.5 units of the camera
- Test hooks: `unicorn.dbgSpeed` pins the speed, `unicorn.dbgStatic` animates in place

### Real-GPU test (Alex's MacBook Pro, Chrome, 5 Nov 2026 evening)
Ran the published build in Chrome on the Mac and let the dream ride gallop through Minty Meadows, a sunset and a night. Steady **120 fps** (the display's maximum) at pixel ratio 1.75 with the grass on, 166-577 draw calls and 510k-640k triangles. No shader problems: the grass, coat glitter, rim light, sparkles, sunset and night all render correctly. Not yet measured on an iPad.

### Test hooks (v0.3/v0.4)
`UA.dbg.sim(seconds)` fast-forwards game time without drawing. `UA.Wonders._grant('giant', unicorn)` forces a wish (ids: flowers, gumdrops, party, rainbow, night, giant, tiny, stars, bubbles). `UA.Magic.rainState()`. `UA.FX.flowerCount()`. `UA.Grass.refresh()`.

### Tested (headless Chromium, no GPU)
Day/night, all spells, arch boost, bouncing, water-walking, fairy-ring teleport, every wish outcome, giant/tiny camera, fountain flow, the whole chime song quest end to end, garland trail (19 flowers in 3 s), sleeping creatures at night, a 60-step randomized soak across all features (no console errors, state stays finite), iPad and phone touch layouts with the new buttons. About 520-620k triangles and 200-530 draw calls depending on the view.

### Known gaps / things to check on the Mac
- The Mac runs it at 120 fps, but the iPad is still unmeasured. Check it first (press ` for the readout). Quick levers if slow: `?grass=0`, lower the pixel ratio cap in `main.js`, reduce `N` in `grass.js`
- At night the near tree crowns turn a dull beige instead of a glowing blue-violet; the crown night glow could be stronger and bluer
- The giant-unicorn wish makes the camera sit farther back; worth a feel check
- Sunset sky and aurora colours were only eyeballed in screenshots
- The rainbow wish at the fountain spawns an arch right over the fountain; the camera can be inside a leg for a moment
- Sound is synthesized and untested by ear

## Twinkle Town (v0.6, Thu 5 Nov 2026 night)
Alex: "make a main street and town populated by magical creatures in one of the worlds". My choices: put it in Minty Meadows, about 90 units west of the spawn (Main Street runs east-west around world (-85, -14)), on a flattened pad that blends into the hills. Trees, bushes, mushrooms, flowers, grass and wild creature spawns keep out of it.

**The town** (`js/town_build.js`, merged into a handful of meshes)
- Ten candy-coloured shops, five on each side of a cobbled Main Street: Post Office, Sprinkle Bakery, Gumdrop Candy Shop, Starlight Library, Cozy Cloud Inn, Blossom Flowers, Sundae Scoops, Twirl Top Hats, Wands and Wonders, Toadstool Toys. Each has its own roof (gable, hip, dome, witch hat, mushroom cap), striped awning, shop window, door, lanterns and a picture sign (the signs share one canvas atlas, so they cost one draw call and non-readers can still tell shops apart)
- A rainbow gate with a hanging welcome sign at the east end, bunting and string lights across the street, lamps along both pavements, benches, a mailbox, barrels
- A plaza with a fountain, three market stalls and benches, and a town hall at the west end with a clock tower whose hands show the in-game time
- Everything glows at night (windows, lamps, lanterns). Colliders have a top, so the unicorn can glide over rooftops. Camera blockers keep the camera out of the big roofs
- Cost: about 100 draw calls on its own

**The residents** (`js/folk_models.js` builds them, `js/town_folk.js` makes them live). 11 shopkeepers plus 5 jelly-bean kids, each a chubby biped made of ~8 merged meshes sharing one toon material:
- Pixel the fox (postman), Baker Bun the bunny, Gumbo the dragon (candy-maker), Professor Hoot the owl (librarian), Nimbus the sleepy sheep (innkeeper), Madame Maple the hedgehog (hat-maker), Misty the cloud-cat (ice cream), Petal the flower fairy (hovers, leaves a sparkle trail), Wizzle the gnome (wand-maker, wand sparkles), Toby the toadstool (juggles three balls), Mayor Marshmallow (top hat, sash, moustache)
- Five jelly-bean kids in different colours and little hats play tag around the fountain ("Tag! You are it!")
- Each shopkeeper works at their shop front with a different animation (kneading, stirring, reading, scooping, stitching, juggling...), strolls the street now and then (the fountain is routed around), and walks home when the sky gets dark. They go through their own door, shrinking as they step in, and come back out in the morning (staggered, so they do not all leave at once). They keep out of the colliders
- They look at the unicorn, turn to face it when it is close, wave and call out a greeting when it arrives (cooldowns so the bubbles never flood), step aside when it gallops through, and cheer when you cast magic nearby (hooked into `Creatures.dazzle`)
- Press E near one to chat (4 rotating kid-friendly lines each, using the unicorn's own name). Baker Bun and Gumbo give a free treat (once a minute or so, never past 30). The wishing fountain prompt steps aside while a resident is close
- Pixel offers the **Special Delivery** quest (a "!" floats over him by day): bring his letters to Bun, Hoot and Petal. Floating letters mark the recipients, three little letters orbit the unicorn, each delivery is automatic when you ride up, the HUD shows n/3, and finishing pays 6 treats with a fanfare. The recipients stay up past bedtime while it is active. Saved with the game and resumed on load. Creature quests wait while it is active
- Cost: about 99 draw calls (far residents are hidden beyond 105 units), about 90k triangles, and 0.045 ms per frame of game logic

**Tested** (headless Chromium): every shopkeeper close-up for model problems, quest offer to completion, E-chat and gift, quest save and resume across a reload, bedtime (all inside within ~12 s) and morning (all out in ~8 s), dusk walk home, a 90-step randomized soak with time jumps, teleports and key presses (no console errors, no resident left the town or went non-finite), and the single-file build.

**Bugs found and fixed along the way:** barrels beside two shop doors trapped residents on the way to bed (barrels moved to the far side), arriving at a door was blocked by the shop's own collider (they now switch to a walk-in state near the door), the plaza stalls were invisible to the camera.

**Known gaps**
- Not measured on a real GPU or an iPad. The residents roughly double the draw calls in the town view (about 100 to about 200)
- The camera can sit just above the edge of the big mushroom roof when you ride along the south pavement, because the pull-in has a 70% floor (to avoid the in-and-out feel)
- Residents are not in the friends book and have no bond hearts. There is no rider avatar yet
- Sounds untested by ear

## Small fixes (v0.7, Fri 6 Nov 2026 morning)
Alex (three notes): "The unicorn tail and mane need reworking - they're very wide" and "It's very hard to say hi to the townspeople because the UI defaults to showing Puddle Cloud Bunny's dialog box instead. It should be able to show multiple dialog boxes when there are multiple people to interact with".

**Tail and mane** (`js/unicorn.js` hair section, `R.Hair` in `js/unicorn_rig.js`)
- Measured in the game (centre-lines, world units, unicorn about 0.9 wide at the hips): tail 1.8 wide at rest and 1.6 at a gallop, mane about 1.5, forelock curls out to 0.9. Causes: the locks sprayed sideways at rest (lateral rest directions up to 0.5), the streaming "fan" vector is normalised by the rig so the old (1.2, 0.2, 0) meant almost purely sideways, the sideways flutter was +/-0.35, and each lock was a fat flattened tube (radius 0.19, 1.3x wider than deep)
- Now: the tail is seven slim locks (was nine fat ones) bunched into one plume, staggered in length and lift so it still looks full from the side; the mane lies along the crest and falls back down the neck; the forelock curls stay on the brow. Fan vectors are mostly "up" with a hint of sideways, flutter is mostly vertical (new `flut` option on a lock), tube radius is about 0.08 to 0.12 and nearly round (`flat` 1.15), and the tail root sways less
- Result: the tail is about 0.5 wide at every speed and the mane about 0.4 to 0.5 (was 1.2 to 1.8)

**Several prompt boxes at once** (`js/ui.js`, `js/main.js`, `js/town_folk.js`, `js/wonders.js`, `js/input.js`, `index.html`)
- Before: a wild friend within 7.5 units always won, so a bunny wandering through the plaza hid the townspeople's "Say hi" box
- Now every creature, townsperson and the wishing fountain in reach offers a card (`UI.offer`), and up to three sit side by side (two on phones). The nearest is outlined and takes E (pet / say hi / wish), F and R for creatures. **Tab** (or d-pad left) switches who is selected, and any card's buttons can be clicked or tapped directly. A small hint shows when there is more than one card. The selection sticks to the nearest one with some hysteresis so it does not flicker, and a manual pick holds while that card stays close
- Cards are stable (they do not reorder as you move), fade in and out, and sit above the touch buttons on phones. Tested: baker plus a bunny (both cards, Tab switch, E on the picked one, clicking the unselected card, leaving range removes both)

**Roofs were penetrable** (`js/unicorn.js`, `js/world.js`, `js/town_build.js`)
- Alex: "the roof of the town can be penetrated if you fly down into them and get stuck". Cause: building colliders only counted when the unicorn was within 2.4 units of the ground, so at roof height it flew straight through walls and roofs. Once inside, the ring of overlapping collision circles kept shoving it around
- Fix: town buildings, the town hall, the clock tower, the fountain and the stalls are now flagged solid (`bld`) and block at any height. The town builds a coarse top-surface map from its real merged mesh (`Town.surf`, 0.6 unit cells, about 5 ms): roofs, awnings, canopies, the clock tower. The unicorn lands on those from above (feet at or above the surface, give or take a 0.6 step), stands on them, rides across them and falls off the edges. Under an awning at street level the surface is ignored, so riding along the pavement is unchanged
- Tested: dives onto all 11 buildings (roof centre, corners, edges), riding off, flying into every shop front at five altitudes and three offsets (no sinking), a 280-check random-input soak in town (no sunk or non-finite positions), a jump under an awning, and close-up views standing on the red roof, the mushroom cap and the witch hat
- Side effect worth knowing: the unicorn can now stand on a roof, which a kid will love. The camera copes (the roof blockers only pull it in when the ray crosses them)

## Simpler for little kids (v0.8, Fri 6 Nov 2026 afternoon; map view rolled back that evening)
Alex: "We need to make it simpler for little kids - and should allow unlimited feeding" and "The WASD control scheme is not intuitive for little kids, can we shift to a more top down view and use the arrows to go North, South, East, West".

**Unlimited feeding** (`js/creatures.js`, `js/ui.js`)
- Feeding no longer needs or uses gumdrops: the treat gate and the decrement are gone from `Creatures.feed`, the card button just says "Feed" (it used to show a count and grey out at zero), and the card no longer re-renders when the count changes
- Gumdrops are now only for wishes at the fountain (2 each) and are still collected from bushes, bakery, quests and rings. The HUD counter stays for that. Whether wishes should be free too is an open question for Alex

**Map view: tried, then rolled back as the default** (`js/unicorn.js` ChaseCam, `js/input.js`, `js/main.js`, `js/ui.js`, `index.html`)
- First cut: a north-up camera looking down from the south at about 57 degrees, so the arrow keys read as North / South / East / West, with a compass chip. It worked mechanically (Up is -z, Right is +x, Down is +z, Left is -x; touch stick, V toggle and dream ride all checked)
- Alex's verdict (same afternoon): "now we can't see the environment. Sorry, go back." The steep angle hides the horizon, the mushrooms and the distant friends, which is much of the charm
- Now: the over-the-shoulder camera is the default again, exactly as in v0.7 (pitch 0.3, FOV 62, drag to look, swings behind when running). The map view is still in the code, one key away: **V** toggles it, and the compass chip only shows while it is on (tap the chip to go back). The saved choice lives in `state.camView` (default 'chase'); the v0.8 `view` key is ignored so saves from the first cut do not stay in map view
- Dream ride (P) now steers by compass heading rather than "forward"; checked in both views
- If the arrows-as-compass idea is revisited, a middle ground is worth trying: a lower angle (about 35 degrees), wider FOV and a camera that is fixed to North but still shows the horizon

**Camera pulled back** (Sat 7 Nov, Alex: "Pull the camera back a bit so we can see more")
- Behind view default distance 9.2 to 12.5 and pitch 0.30 to 0.33 (about a third farther back, a little higher); the scroll-wheel zoom now goes out to 26 (was 18). Checked in the meadow, down the Twinkle Town street and in the air

**Arrow keys follow the child** (Sat 7 Nov, Alex: "In play testing little kids can't use the WASD controls intuitively. They use the arrows to go the way they want to go so if they push left or down we need the camera to move to follow the unicorn")
- Cause: the behind camera only swung round behind the unicorn in proportion to how hard Up was held (`k = 0.35 + input.y`), so Left got a weak swing and Down none. The unicorn would run off sideways, or towards the camera, and the child could not see where it was going
- Now (`ChaseCam.update` / `steerYaw` in `js/unicorn.js`, `keyOnly` in `js/input.js`, `js/main.js`): for the arrow and WASD keys the view turns round behind the unicorn whichever way it goes (up to about 2.2 rad/s, so a quarter turn takes about a second and a U-turn about two), and keeps turning for 2.4 s after the key is let go so the next push starts from a view that matches how the unicorn faces
- To stop the turning view feeding back into the steering (hold Left and spiral), each new key combination locks in "which way is that on screen right now" and holds it while the key stays down. So Left means "go to the left of what I see" and goes straight that way; tapping Left again turns another quarter. The latch only applies to keys; touch stick and gamepad keep the old live mapping and gentle swing, and the dream ride and the V map view are unchanged
- Tested headless with real key events: Left from north runs a straight line west and the view follows round in about 2 s; Down from west turns the unicorn about and the view swings round behind it; a tap of Left then Up carries on the way the unicorn faces; Up+Right goes straight north-east. Also the Down turn-around in Twinkle Town street and the 280-check town soak (no problems)
- Open: a hold-to-circle steering style for older kids is gone for the keyboard (a held direction is a straight line). A "steering wheel" option could come back later if wanted

## Cartoon graphics rework, phase A: inked outlines and bold cel shading (v0.9.0, Sat 7 Nov 2026)
Alex: "Let's rework and upgrade the graphics to make them more cartoon and fun." His choices: inked outlines with bold cel shading; all four focus areas (the unicorn, creatures and townsfolk, the world, motion and fun); spend more GPU and add a Quality switch.

Plan: A (this entry) is the rendering look. B is the unicorn redesign, bigger-eyed creatures and folk, and squash-and-stretch motion. C is the world palette (sky, clouds, trees, grass, water, a bolder town).

**What changed** (new `js/cartoon.js`, plus small edits in `core.js`, `daynight.js`, `main.js`, `input.js`, `ui.js`, `index.html`, `town_build.js`, `world.js`, `effects.js`, `unicorn_rig.js`)
- **Cel shading.** Every material was already a toon material; the lighting bands are now four crisp steps (0.2 / 0.42 / 0.86 / 1.0) instead of three soft ones. The dark bands are tinted lavender-blue rather than grey, and the final colour gets a 1.3x saturation lift. Done by patching three's toon shader once, so it costs next to nothing. A `GLOSS` flag exists for a crisp white sun-glint dab on shiny things (not applied to anything yet)
- **Lighting.** Sky light turned down (x0.66) and the sun turned up (x1.7), because the old flat 2.15 sky light washed every colour out to pastel and flattened the bands. Sunrise, sunset and night scale the same way
- **Inked outlines.** Each solid mesh gets a dark-plum shell (an inverted hull pushed outwards in screen space), so every line is about 2.3 px wide on screen at any size, thinning to half with distance. Fog-aware, instanced meshes supported (trees, rocks), hair included. Smooth push directions are welded by position so hard-edged boxes (the shops) keep closed outlines. Tiny things, glass, glow sprites, flowers and anything transparent are skipped; outlines beyond about 95 units are switched off; props that appear later are outlined by a rescan every 1.2 s
- **Cobblestones.** The old ones were near-white on near-white; now saturated candy stones (pink, apricot, mint, sky, lilac, butter) on deep grape grout
- **Fancy / Simple switch.** G key, or the new button in the help panel. Fancy = outlines on; Simple = outlines off (the cel shading stays, it is free). Saved with the game. The frame governor now drops to Simple by itself if Fancy cannot hold about 34 fps, after lowering the pixel ratio and before turning the grass off. `?keepfancy` turns that fallback off for testing

**Cost, measured in the headless GPU-less renderer, Twinkle Town main street:** 847 draw calls and 985k triangles in Fancy; 729 calls and 957k triangles in Simple. So outlines add about 16 percent more draw calls and 3 percent more triangles. Not yet measured on the Mac GPU or an iPad

**Checked:** meadow, the town street, close-ups of the unicorn and creatures, Simple mode and the toggle button label. Not yet checked: night and sunset colour of the outline, the soak run, an iPad

**Known rough edges for phases B and C:** the unicorn's pink muzzle is oversized from the front; the sky, grass and clouds are still pale next to the new town; creatures and folk still have small eyes

## Cartoon graphics rework, phases B and C: characters, motion and world palette (v0.9.1, Sat 7 Nov 2026)

**Phase B: the unicorn** (`js/unicorn.js`, `js/core.js`, `index.html`)
- Rounder, cuter head: the head shape is a bigger, rounder cranium with a much shorter, softer muzzle (the old one was long and the pink patch covered a third of the face), and the whole head is scaled 1.1x. The pink patch is now a small nose patch only
- Bigger eyes (1.2x) set further forward and closer together so the face reads from the front, not just the side; bigger lashes and cheek blush; nostrils and smile moved to the new nose. Ears and horn re-seated on the rounder skull
- Chunkier legs (about 20 percent thicker, leg lengths and gait untouched), bigger hooves and socks
- Richer coats: Rose, Lilac, Mint and Sky are more saturated, and two new coats were added, Sunny and Peach (7 in all; the picker shrinks on phones so they fit). Saved games keep their coat choice because the first five keep their positions
- Shiny: the coat, muzzle, horn and hair now get a crisp white sun-glint dab (the new `GLOSS` flag in `cartoon.js`), which shows on the coloured coats
**Phase B: creatures and townsfolk** (`js/creatures.js`, `js/folk_models.js`)
- Wild friends: eyes 1.38x bigger with a second little sparkle highlight
- Townsfolk and the town kids: eyes about 25 percent bigger, a larger main highlight and a second small one, so Bun, Gumbo, Pixel and the kids look wide-eyed and friendly. (The owl professor already had big spectacle eyes)
**Phase B: motion**
- Squash and stretch (a spring on the unicorn's body, scaled about the hooves so the feet stay planted): springs up tall on a jump (more on the double-jump), stretches slightly in the air by speed, squashes flat on landing in proportion to how hard it hit (up to about 15 percent shorter and 7 percent wider) and wobbles back, plus a tiny idle bounce
- Rainbow star ring: a ring of 7 stars at take-off, and 8 to 24 on landing depending on the fall (`FX.ring` in `effects.js`)
- Blinking was already there
**Phase C: the world** (`js/world.js`, `js/core.js`, `js/main.js`)
- Candy ground colours: mint, lime, aqua, pink meadow, sand, pond beds and lavender hills are all one step more saturated; the four region tints, tree crowns (per region and the scattered ones) and the water (a brighter sky-blue, a little more opaque) too
- A real sky: the chase camera only ever sees the bottom 13 degrees of sky, which used to be the pale pink horizon band, so the world never looked like it had a blue sky. The sky gradient is now much tighter (pink glow at the horizon, blue by about 12 degrees up), so the sky at the top of the screen is a bold blue, and the clouds read as white fluffs against it
- The mountain ring is about 40 percent lower (30 to 56 tall instead of 50 to 90) with snow-capped tops and lighter lavender rock, so the sky shows above the hills instead of a pink wall. Side effect: a few trees and mushrooms near the world edge moved, and about 5 more trees appeared
- Thinner fog (0.0043 to 0.0028) so distant hills keep their colour, and the base sky and fog colours are a little richer
- Lighting: sky light x0.66, sun x1.7, bands 0.2 / 0.42 / 0.86 / 1.0, saturation 1.3 (from phase A, baked in)
**Checked:** dawn, day, sunset and night in the town (outlines read at night), the meadow, the start screen on desktop and phone width, jump and fall squash (sampled frame by frame and screenshotted), the random-input soak (60 steps) and the 280-check town soak (4 flags, all riding under the rainbow gate arch at the west end, which the test counts as "inside" because the arch is a tall surface; the old build did not visit that spot with the same random seed)
**Not yet checked:** a real GPU or iPad (outline cost), the look of the Sunny Glades and Rose Grove border (the ground there is a muted peach, a little dull next to the rest), wild-creature faces up close from the front, and the night meadow from the normal chase view

## Idle glitter-poop gag (v0.9.2, Sat 7 Nov 2026)
*Retuned in v0.9.3 (below): about 20 seconds of standing still instead of 4, and a pile about half the size. The numbers in this section are the original v0.9.2 ones.*
Alex asked: "Make the unicorn do glitter poops if the user is idle for a few seconds".
- **Trigger** (`updatePoop` in `js/unicorn.js`): during play only (never on the title screen), when there has been no input at all for about 4 seconds (3.6 to 5.2, re-rolled each time) and she is standing on the ground (not in the air, not swimming, not giant). Any key, stick, tap, jump, magic, pet/feed/play, camera drag or menu key counts as input, and so does the dream ride. At least 6 seconds between gags, so a roughly 8 second rhythm while you keep standing still
- **The gag** (about 3.9 s): the tail lifts and trembles, she squats (the legs bend), screws her eyes shut and lays her ears back, with a little wobbling hum and a shimmer of glitter at the tail. At 0.85 s a soft-serve swirl of three pastel rainbow layers plops out behind her, one layer every 0.34 s with a squishy overshoot, a rising "bloop" each and a curl on top. Then a happy hop, a chirp and two hearts, and she glances back over her shoulder at it
- **The pile** (`js/glitterpoop.js`, new): drawn 1.3x oversized so small eyes can spot it, glossy and outlined, twinkling glitter around it. After 7.5 s it pops into stars and hearts, or at once if you bump into it (after the first 2 seconds). At most 3 at a time (the oldest pops to make room). Three piles are built once and reused, so nothing is created or leaked while she stands about
- **Interrupting:** any input before the plop cancels the whole thing (she thinks better of it); input after the plop ends the gag and leaves the pile
- **Safe spots:** it only happens when there is flat dry ground right behind her (no cliff edge, no water unless she has the rainbow anklets). A giant unicorn makes a giant pile
- Works the same in Simple mode (outlines off) and at night (the pile glows a little)
**Checked:** the full sequence in frames (wind-up, plop, relief, look-back, sparkling, pop) in the meadow and the glades at 2x; night; Simple mode; cancel before and after the plop; no gag while jumping or on the title screen; the cap of 3 piles; bumping a pile; the outline list does not grow with use (12 meshes outlined once); an idle soak at 6 places x day and night x 2 sizes (no NaNs, every pile on the ground); the 60-step random-input soak on the built single file, no console errors
**Not yet checked:** the sounds by ear (hum, bloops, chirp), the timing by eye on the Mac, and whether about 4 s is the right amount of "a few seconds" for kids

## Smaller, rarer poops and animals that play by themselves (v0.9.3, Sat 7 Nov 2026)
Alex asked: "I think they shouldn't have to do anything for the animals to play and frolick. Unicorn poops are too big and too frequent, they should take like 20 seconds".
**Glitter poops** (`js/glitterpoop.js`, `js/unicorn.js`)
- I read "take like 20 seconds" as: about 20 seconds of standing still before each poop. The first one comes after 18 to 23 seconds (re-rolled each time), then at least 20 seconds must pass before the next one. Measured on the real defaults with the unicorn standing still: poops at 20.8 s, 46 s and 69.1 s
- Pile size 1.3x down to 0.7x (a little over half its old size, about knee height on her), it now lasts 6 seconds instead of 7.5, and its pop is smaller (14 stars, 2 hearts and 6 sparkles instead of 24, 3 and 10)
**Animals play and frolic with no buttons** (`js/creatures.js`)
- Ambient frolics (`Cr.startFrolic`): when an idle animal's frolic timer is up (the first one 2 to 12 seconds after the game starts, staggered, then every 9 to 23 seconds, 16 to 30 for the sleepy dragons) it picks one of three romps and does it whether or not the unicorn is near: chase a nearby buddy (within 17 units) round in a ring with both animals circling, zoom about to random spots, or spin and leap. 3 to 8 seconds each, with sparkles, a fast tail wag, head up, hops, the odd heart, and one happy chirp at a time so a field of frolickers is a murmur. In a 60 second test with the unicorn parked away, 59 frolics began among about 20 awake animals (5 rings, 44 zooms, 10 spins)
- Auto-play (`Cr.autoPlay`): stand still or ride slowly (under 3.5 speed) within 10 units of an animal (13 for a follower) for 1.3 seconds and it comes over to play: it circles the unicorn for 6 seconds, hopping, sending up hearts and sparkles and calling "Catch me!" or "Let's play!". Wild animals play too, with no need to pet them first; they get hearts but no bond, while a friend earns its bond heart as before. At most 2 play at once, and each then rests 26 to 38 seconds
- Small touches: followers give a happy skip now and then as they trail, and an animal waiting near a standing unicorn gives little excited bounces
- Unchanged: animals still nod off at night (friends stay up), shy bunnies still bolt from a galloping unicorn, the quest's tag fox still runs away, and the Pet, Feed and Play buttons all still work (Play still says "Pet me first" on a wild animal, which is now optional since it will play anyway)
**Checked:** poop timing on the real defaults and pile size in a screenshot; ambient frolic counts with the unicorn far away; a wild sheep auto-plays with no press and earns no heart; a friend earns its heart; a crowd of 5 around her gives at most 2 playing; a bunny and a sheep forced into a ring really circle (positions sampled); a frolic soak across the world at hours 12, 18 and 23 with no bad positions and no animal stuck in a frolic with no data; the 60-step random-input soak on the built single file, no console errors
**Not yet checked:** by eye on the Mac, the sounds by ear, and whether 6 seconds of play and 26 to 38 seconds of rest feel right to kids. The greyed Play card was removed in v0.9.5 (it now only shows once the animal is a friend)

## Starlight Castle, sparkle portals and Princess Starla (v0.9.4, Sat 7 Nov 2026)
Alex asked: "Make another area that features a princess castle instead of a town accessible by a sparkly portal in the other levels. There should be a magical princess to meet who will hop on the unicorn and ride".
Defaults I chose (all easy to change): the area is called **Starlight Castle**; there are two sparkle portals into it, one in the home meadow and one inside Twinkle Town's east gate; the princess is **Princess Starla**; everything is automatic, with no buttons (she greets you, asks for a ride, hops on by herself, and hops off by herself).
**The realm** (`js/realm.js`, `js/castle.js`, height field in `js/world.js`)
- A second landscape far to the east (world x about 1500, the main world is untouched): a flat plateau for the castle and plaza, rolling pastel hills, then candy mountains. Heights come from `realmHeight` when x > 700, so `groundAt`, `slopeAt` and water checks just work there. `UA.World.clampPlay` / `outOfBounds` replace the old origin-centred edge clamps (the unicorn and the animals stay inside the realm's own play area)
- Everything in the realm is built in local coordinates inside one Group at (1500, 0, 0). The main world's meshes are hidden while you are in the realm and the realm's while you are not (`UA.mainWorld`, `Realm.setIn`), so the extra area costs nothing when you are elsewhere
- **The castle** (`castle.js`): a pink and peach castle with crenellated walls, a gatehouse and gate towers, corner and side towers, a central keep with a tall spire and four turrets, waving flags and banners, a rose window, a big door with a porch, a courtyard with a sparkling fountain and flower beds, a red carpet, lamps that glow at night, topiary and rose arches along a checkered Royal Road, a plaza with a star rosette, benches, a signpost and a pumpkin carriage. Walls and towers have colliders
- 150 lollipop trees and about 3200 flowers, pastel clouds and a giant rainbow behind the castle, 9 residents (3 bunnies, 2 sheep, 2 foxes, 2 dragons) so the HUD friend total goes from 30 to 39
**Portals** (`makePortal`, `Realm.go`)
- A swirling sparkle portal (gold, pink and lilac rings, glowing pillars, orbiting stars) in the home meadow (near the start, facing it), in Twinkle Town inside the east gate, and a return portal at the end of the Royal Road. Ride into one and there is a burst, a chime, a flash and you arrive at the other end (a 3 second cooldown stops ping-ponging). Friends who follow you come too. A one-time invitation toast appears near a home portal after you have played 45 seconds. `UA.state.realmVisits` counts trips
**Princess Starla** (`js/princess.js`)
- A chibi princess built from toon shapes (big sparkly eyes, golden hair with a bow and swinging locks, a tilted gold crown with gems, a pink gown with gold stars, a star wand that glows); each rigid part is merged into a few vertex-coloured meshes, so she costs about 27 draw calls
- **She waits** by the keep door, glancing at you, waving when you are near and now and then twirling her wand with sparkles. **When you ride up (within about 34 units) she skips over** (and walks around the fountain rather than into it), curtsies and introduces herself: "Hello! I'm Princess Starla!", "Welcome to Starlight Castle!", "May I ride with you?" (a shorter greeting when you come back)
- **She hops on** by herself after about 7 seconds if you stay near and standing nearly still (4 seconds on later visits): a twirling leap onto the saddle with a burst of sparkles and hearts, a fanfare and a toast. If you ride off instead she waves and says "Come back soon!"
- **She rides**: parented to the saddle, so she bobs, pitches and squashes with the unicorn and scales with a giant unicorn. She sits with her gown flared over the saddle, leans into turns, her hair streams back with speed, her arms go up when you jump or glide, she twirls her wand now and then (the sparkle makes nearby friends cheer), giggles when you do a glitter poop, and chatters (rate-limited: "Wheee!", "Faster, faster!", a hello to friends). She rides with you through the portals
- **She hops off** when you stop for a moment at the castle after riding at least 14 seconds (about 2.4 s of standing still, within 26 units of the castle), or after standing still for 8 seconds anywhere. At the castle she thanks you and skips home; anywhere else she says goodbye and vanishes in a twinkle back to the castle. About 20 seconds before she offers another ride
- Also in this release: two new sounds (a giggle and a three-note hello), and a fix for a speckle on flat walls at noon (a toon-shading band boundary, nudged in `js/cartoon.js`)
- Friendships with the castle's animals are saved and restored like the others (the residents are created after the save is first applied, so `Realm.build` re-applies the saved bonds)
**Checked:** the realm's draw cost in the headless test (outlines on): 207 to 267 calls and about 500k triangles at nine spots across it, against 710 to 892 calls and about 1M triangles in the meadow and Twinkle Town (the princess is about 27 of the calls, down from 79 before her parts were merged); the meeting in frames (greeting, curtsy, hop-on, riding at rest, galloping with her hair streaming, jumping, turning, hop-off with a twirl and a thank-you, skipping home round the fountain); riding through the return portal, the meadow portal and back with her aboard (she stays on the saddle, with a line for each side); the standing-still dismount in the meadow (goodbye wave, then a twinkle and she is back at the castle, hidden outside the realm); both home portals by day and at night, and the Royal Road, the courtyard and the princess at night (lamps with halos, the rose arch, the lit castle); a 90-step random-input soak inside the realm with teleports, portal trips and long stands (princess states wait, come, intro and ride all seen, no NaNs, no console errors, her parent and visibility always matching her state)
**Not yet checked:** the sounds by ear (giggle, hello, portal chime), how the realm and the princess feel on the Mac and an iPad (the real GPU cost with outlines), whether 7 seconds before the first hop-on and 14 seconds before the first hop-off feel right for kids. Open questions from before were answered on 9 Nov (see v0.9.5), except follow-the-child steering for the touch stick

## Townsfolk out at night, easier animal cards, free wishes (v0.9.5, Mon 9 Nov 2026)
Alex asked: "Townsfolk should be visible at night. Simpler for kids means easier menus for interacting with the animals, free fountain wishes".
**Townsfolk stay out at night** (`js/town_folk.js`)
- The eleven shopkeepers and five kids no longer go to bed: nobody walks home, goes inside or hides when it gets dark, and the first frame puts everyone out whatever the hour. One constant, `BEDTIME = false` near `goHome`, brings the old bedtime routine back
- Pixel's Special Delivery quest used to start only in daytime; it now starts any time (the "!" and riding up to Pixel work after dark, and the three deliveries complete at night)
- No new lights or glow were needed: the street lamps, shop windows and lit cobbles already show them well at night
**Easier animal cards** (`js/ui.js`, styles in `index.html`)
- **One big card.** The nearest animal (or townsperson, or the fountain) gets a large card with big square icon buttons (a 36 px picture over the word, 84 px or wider, and 92 px on touch screens), with the key letter underneath on a keyboard
- **No greyed-out button.** Pet and Feed are always there; Play appears only once the animal is your friend (before, it sat there greyed out and did nothing)
- **Other friends shrink to name tags.** When several are close, only the focused card keeps its buttons; the rest become small name tags (name and hearts). Tap a tag, or press Tab, to switch to that friend. Still up to three cards (two on touch)
- **Tap the card to do the main action.** Tapping or clicking anywhere on the big card pets the animal (says hi to a townsperson, makes the wish at the fountain), so a child never has to hit a small button; the buttons still work and E, F and R are unchanged
- A phone held sideways puts the card at the bottom centre between the stick and the buttons (it used to climb up under the top bar)
- Help text updated to match
**Free wishes** (`js/wonders.js`)
- Wishing at the fountain costs nothing: no gumdrop check, no 2 gumdrops taken. The card says "Make a wish" and just rests for about 3.5 seconds after a wish (showing "sparkling..."), so a wish can't be started twice. Gumdrops are now only a collectible count (they are still picked from bushes and earned as rewards); the Gumdrop Rain wish still works. The help text no longer says to toss in gumdrops
**Checked** (headless Chromium, outlines on): the plaza and Main Street at night with the residents out (screenshots: Gumbo, a hedgehog in a wizard hat and the others stand out against the lit cobbles); a 90-step random-input soak at night with time jumps (about 4900 town updates, 0.11 ms each, no NaNs, nobody outside the town, none inside, no console errors); Pixel's quest start and all three deliveries at 22:30 (9 treats awarded); the animal card with a wild bunny (Pet and Feed only), tapping the card (friend made, Play appears), two animals (one big card plus a name tag, tapping the tag switches focus), the touch layout in portrait (420 x 760) and landscape (844 x 390); the fountain with 0 gumdrops (wish granted, treats unchanged, a second tap during the rest ignored, another wish after the rest)
**Not yet checked:** by eye on the Mac and with real little fingers (are the big buttons big enough, is tap-the-card obvious, do the name tags confuse anyone); whether townsfolk who never sleep feel odd when you ride into town at 3 in the morning; what gumdrops are for now. Still open for Alex: follow-the-child steering for the touch stick; whether gumdrops should unlock something, since nothing costs them any more

## Open castle gardens, Frostglow Peak and Princess Flurry (v0.9.6, Mon 9 Nov 2026)
Alex asked: "The princess' castle has some areas around the walls where kids get stuck. Remove the walls and upgrade the gardens around her castle. When that's done build another world accessible by another portal that features a Frozen-esque ice forest and mountain with an ice castle at the top. This world should be populated by ice and snow animals and feature its own ice princess in the castle."
Defaults I chose (all easy to change): the new world is called **Frostglow Peak** and is an original design (no Frozen names, characters, songs or logos: a snowy pine forest, a spiral road up a glittering mountain, a frozen lake and an ice castle on top); its princess is **Princess Flurry** (silver-lavender twin-puff hair, ice-blue snowflake gown, crystal crown, snowflake wand); the animals are **Snow Bunnies, Frost Foxes, Waddle Penguins, Polar Cubs and Ice Dragons**; it is reached through the two sparkle portals that already existed (home meadow and Twinkle Town), each of which now has a second, icy portal beside the Starlight one, and a return portal stands on the arrival plaza.
**Starlight Castle: no walls, new gardens** (`js/castle.js`, `js/garden.js`, `js/realm.js`)
- The castle walls and gate towers that made pockets are gone, so nothing encloses the grounds and the lawns round the keep are open parkland you can ride across in any direction. The keep with its spire and four turrets, the porch, the fountain court, the carpet and the Royal Road remain
- New gardens (`garden.js`): two formal parterres (hearts west, stars east) with a crystal unicorn statue and a spinning golden sundial between them, the lily pond with a candy willow and bench, a tea gazebo laid for the princess, the Moonflower Walk to a spinning unicorn carousel and a tree swing, wildflower beds, and butterflies (one draw call)
- Rule used everywhere: every solid thing stands at least six steps from the next, so even the biggest unicorn (radius about 1.45) can never be pinched. Checked with a grid flood-fill at three unicorn radii: no pockets
**Frostglow Peak: the world** (`js/world.js` height field, `js/ice.js`, `js/ice_castle.js`)
- A third landscape at world x about 2600 (main world untouched, Starlight at 1500). Heights come from `iceHeight` when x > 2100 so `groundAt`, `slopeAt` and the rest just work. The play area is a capsule of radius 122 round the line from the mountain to the portal. Everything is built in local coordinates in one Group and switched on and off with the area (`Realm.cur` is now main, star or ice; `Realm.inIce`), so Frostglow costs nothing while you are elsewhere
- The mountain (radius 135, 64 high) has a level summit and one lap of **spiral road** (a level terrace 14 wide, 519 long, lamps along the inside edge, five ice arches, a brick and snowflake texture) from the south foot to the castle forecourt; the banks beside it are steep, so the road is the way up (gliding off a jump also works)
- A frozen lake with cracks and snowflakes (it sparkles under you and a toast says "Skating!"), a snowflake plaza with a rosette and four giant crystal formations, 340 snowy pines (instanced), about 50 crystal clusters, 7 snowmen, 3 igloos, a signpost, 16 clouds drifting below the summit so the castle floats above them, 1500 falling snowflakes (one shader, wrapped round the unicorn) and a pale lilac sky with an aurora at night
- **The ice castle** (`ice_castle.js`): a great hall with a central spire tower, six hexagonal turrets with pennants, arched windows that glow at night, a snowflake rose window, banners, a door with a porch and crystal canopy. No outer walls. In front: a courtyard with a rosette, carpet, a frozen fountain with a spinning star, a gate arch, lamps, benches and obelisks; two frost gardens with a crystal-flower parterre (864 instanced flowers) and four ice sculptures (swan, heart, bunny, star)
**Princess Flurry and the refactor** (`js/princess.js`)
- `princess.js` is now a factory: `make(cfg)` builds a princess from a config (palette, hair style, home, bounds, lines, which realm she lives in, which save flags she uses). `UA.Princess` is Starla and `UA.IcePrincess` is Flurry; the behaviour (wait, come, intro, hop on, ride, hop off, poof) is shared and unchanged. Only one princess rides at a time (`other`), and a princess who is riding can be taken through a portal; if she is still for 8 seconds somewhere else she hops off and vanishes in a twinkle. Saved flags `iceMet` and `iceRode`
**The animals** (`js/creatures.js`)
- 12 residents, ids from 40 up: 3 Snow Bunnies in forest clearings (scarf, big fluffy tail, cheek fluff), 2 Frost Foxes (glowing ice-blue star on the forehead, sparkly paw prints as they run), 3 Waddle Penguins on the frozen lake (a waddle with swinging flippers, scarf), 2 Polar Cubs near the snowmen (chubby, sleepy, scarf), 2 Ice Dragons in the castle gardens (they puff sparkly snowflakes when happy). Their records carry `area: 'ice'`, so the main world's spawner skips them and `Creatures.addIce` places them; the HUD friend total goes from 39 to 51. New names, blurbs and voices; the friend book shows "???" until each species is met
- Other small changes: the friend heart height and the bubble size round a creature are now table entries (`mh`, `bub`) instead of species tests; the dream-ride and quest code are untouched
**Bugs found by testing:** the far-west stretch of the spiral road lay outside the original play area (radius 100), so a unicorn would have been stopped about a fifth of the way up (found by driving a unicorn up the road; the play area is now 122 and the climb finishes at all three unicorn sizes); one forest clearing for the Frost Foxes was on a steep slope (moved, plus another one off the slope)
**Checked** (headless Chromium, outlines on): the first look, the road, the castle, the lake and the courtyard by day and by night; a unicorn driven up the whole road at sizes 0.55, 1.0 and 1.7 (about 30 s at a gallop each); pinch analysis of the ice world at three radii (only 1-cell gaps between pairs of trees, plus the solid inside of the hall); Flurry's whole sequence (come, intro, hop, ride, hop off, poof); riding Flurry through the return portal and into the meadow; Starla still greets and rides after the refactor; a 70-step soak of teleports across the world at three sizes (no bad positions, no errors); memory plateaus (no leak); pet, feed and play on each new species. Draw cost in the ice world: 150 to 300 calls and 330k to 420k triangles, against 700 calls and about 980k in the meadow
**Not yet checked:** by eye on the Mac and an iPad (real GPU cost); the ride up the road at walking pace takes roughly 75 s, which may feel long to a small child (a shortcut or a faster "mountain wind" could be added); the animal voices by ear; that the ice dragons (dark at night under the moon) look right to you
**Follow-up fix: the icy portals (Tue 10 Nov 2026)** (`js/realm.js`)
Alex: "There are two portals in the town and both lead to the castle world not the ice world, can you make one go to the ice world and make it blue and ice style visually".
- **What was wrong.** The meadow's icy portal was never placed (no free flat spot within reach of its target, so `findSpot` returned nothing), and the town's icy portal stood at the far north-west of the town, so the only two portals Alex could find were both Starlight ones
- **Fix.** Portal placement now tries a list of spots with a larger reach and keeps portals at least 22 units apart. All four home portals are placed: meadow Starlight (-15, 1) and meadow icy (45, -4), town Starlight (-38, 8) just inside the east gate and town icy (-37, -35) on the other side of the gate
- **Blue and icy look.** The icy portal now has its own disc shader (deep azure and cyan, a six-armed swirl and six white spokes like a snowflake, no rainbow), hexagonal ice-crystal pillars with snow drifts at their feet, a ring of crystals round a pale-blue pad (the front stays open), a bluer ring, orbs and glow. The Starlight ones are unchanged (pink, gold and lilac)
- **Checked:** all four portals ridden into from 14 units away with a steered unicorn: each leads where its colour says, and the return portal brings you back beside the portal you used; screenshots by day, by night and from the air
- **Then Alex asked to remove one of the two Starlight portals.** I took out the meadow's one, so Starlight now has one portal (in Twinkle Town just inside the east gate) and the ice world has two: one near the start in the meadow at (-15, 1) and one on the north side of Twinkle Town's east gate. If you want Starlight back near the start, add a `place()` for `dest: 'star'` in `buildHomePortals`. When you arrive home with no remembered portal (rare), you are now put beside a portal that leads to the place you left

Still open for Alex from before: follow-the-child touch steering, and what gumdrops should unlock now that nothing costs them.

## Ice world: a real mountain edge, and animals that lead the climb (v0.9.7, Tue 10 Nov 2026)
Alex: "For the ice world there is an impenetrable wall inside the bounds - rework it so that is at the edge of the mountains bordering the world like in the town. Also, on the ice world the animals should lead and encourage the player to climb the mountain."

**1. The edge of the ice world is now a mountain wall, like the town's** (`js/world.js`, `js/ice.js`)
- **What was wrong.** The ring of hills round the world only began to rise *at* the invisible edge (`playR` 122), so at the edge the ground was still almost flat (about 0.2 m up): a kid rode straight into an invisible wall in the middle of a snowfield.
- **Fix.** `ICE.playR` is now 150 and the ring of ice mountains starts rising at `playR - 36` and is 42 wide (`ICE.ringW`), computed *before* the road is levelled so the road is untouched. At the edge the ground is about 45 m up a steep face (89 % of the ring's height), exactly the proportion the main world's candy-mountain wall has. Beyond the crest the ridge eases down to 45 % so the view from the summit is a sea of peaks and not a flat table.
- Supporting changes: the terrain plane is bigger (460 x 640, 184 x 256 segments) so it still reaches the horizon; the rim tint (rock-blue on the mountain faces) starts at `playR - 30`; pine forest 340 -> 430 trees over a wider area; crystals 46 -> 56. The play capsule still wraps the mountain and the plaza.
- **Checked.** Driving a unicorn at the edge from four directions (east, west, north-west, south): she climbs the face and stops about 45 m up (speed 4.9 at the end), at 150 from the capsule every time. The slope profile (east and south) is 4 m flat to 120, 8 m at 130, 25 m at 140, 45 m at 150, crest 49 m at 155. Screenshots from the ground and from the summit.

**2. Trail guides: seven animals lead and encourage the climb** (`js/ice_guides.js`, new; hooks in `creatures.js`, `main.js`, `realm.js`, `ui.js`, `index.html`)
- Seven new residents (Flake the Snow Bunny, Snuggle the Polar Cub, Rime the Frost Fox, Slider the Penguin, Sprinkle the Snow Bunny, Sleet the Frost Fox, Nanook the Polar Cub) wait along a path from the arrival spot, up the spiral road and into the castle forecourt (567 m long). The friend total goes from 51 to 58.
- **Leapfrog.** Each guide owns a stretch (about 74 m). The first stands 20 m from the arrival spot (at the plaza's edge, in plain view) and greets you at once ("Follow me up the mountain!"). It stays about 24 m ahead of you along the road: it runs ahead when you come, stops and faces you (bouncing, waving) when you fall behind, and speeds up a little with you (never faster than 1.9 x its own run speed). At the end of its stretch it says "My friend will lead you from here!" and the next guide, waiting a few metres further on, takes over. If you gallop past, it cheers (hearts, a jump, "See you at the top!") and stays put.
- **Encouragement.** Greeting on first meeting ("Hi again!" lines after you have been to the top once), a cheer every 5 to 8 s while it runs ahead of you, a call to come on if you stand still for 5 s or wander more than 26 m from it, a handoff line, a passed line. Bubbles are limited to one per guide per 3.5 s and one every 1.4 s overall. Sparkly footprints behind a running guide, and a soft light floating over each guide (faint by day, bright at night) so it can be spotted far up the road in the dark.
- **A climb meter.** A mountain-icon pill in the HUD ("Climb 32 %" up to "At the top!"), toasts at 25 %, 50 % and 75 % ("Halfway up!") with rising chimes and a sparkle burst, and a fanfare, burst and cheering hearts on reaching the forecourt (the first time says "You climbed Frostglow Peak!", later times "Back on top!"; saved as `iceTop`).
- **How it is built.** `UA.IceGuides.update` finds your position on the path (nearest point, smoothed) and tells each guide where to stand and whether to run or wait; the creature's own update does the moving (a new `guide` branch after `play` and before `tag` in `Creature.update`). Guides do not nap at night, do not run the auto-play behaviour or get picked as frolic buddies, and a friend who has been asked to tag along stops guiding. `Realm.go` resets them to their posts on every arrival. Pet, feed and play still work on a guide as on any animal.
- **Checked** (headless Chromium): walking up with a steered unicorn at three paces (full walking speed 10.5 reaches the top in 54 s; a slow walk at 0.45 stick takes about 74 s; a gallop about 30 s); the whole chain of seven greets, leads, hands over and cheers in order, and a guide that is passed stays put and cheers; standing still for 14 s makes the guide ahead call you on and bounce; riding back down makes the guides trot back to their posts and greet you again next time; the night climb (guides awake, lit); a friend asked to tag along stops guiding and loses its light; the milestone toasts, climb pill and fanfare; a 5-round soak (up the mountain, home through the return portal, repeat at noon, evening, midnight, dawn, noon) with no errors, textures steady (15 to 17) and geometries +22 (lazy effects), the climb time identical each round; all three home portals and the Flurry and Starla ride sequences re-run after the changes.
- **Draw cost.** Ice world now about 130 calls and 470k triangles at the foot and 300 calls and 570k at the summit (it was 150 to 300 calls and 330k to 420k): the bigger terrain plane and 90 more trees. The meadow is about 980k.
- **Not checked.** By eye on the Mac and an iPad; the sounds (fanfare and rising chimes) by ear; whether a real child follows the guides or rides off past them (the guides never block you, and nothing is lost either way); whether seven bubbles of chatter is too much or too little.
- **Not guides.** The 12 original residents (lake penguins, forest bunnies and foxes, cubs, the two castle dragons) are unchanged.

## Ice world: Flurry easy to find, clouds that clear the mountain, and an ice slide (v0.9.8, Tue 10 Nov 2026)
Alex: "It feels great. I didn't see the princess at the top. The clouds are clipping into the mountain. Can you make an ice slide down the mountain"

**1. Princess Flurry is now easy to find** (`js/princess.js`, `js/realm.js`, `js/ice_guides.js`, `js/ui.js`, `js/ice.js`)
- **Why she was missed.** She waited at the castle door (local 0, -111), about 25 m behind the fountain and under the porch, so from the forecourt she was a tiny figure in front of a huge castle, and she only reacted to a unicorn within 34 m.
- **Fix.** Her post is now out in the open at the forecourt (`ICE_PRINCESS_HOME` 5, -96, beside the carpet and between the first pair of lamps). She waves from 90 m away and comes out to meet you from 46 m (was 34), set by new `waveR` and `comeR` on her config (Starla keeps 34). While she waits there is a **beacon** over her: a blue column of light with a white core and a white-and-blue snowflake that turns and bobs about 37 m up (normal blending, in real colours, because a pale additive glow vanished against the pale castle). It fades out when she comes to you and back in when she is waiting again. The HUD climb pill says "Say hi to Flurry!" once you are at the top until you have met her (then "At the top!"), and the toasts say she is waiting by the fountain.
- **Checked.** Walking up with the guides: she leaves her post while the climber is still 43 m away on the east side of the mountain, meets them on the road in the forecourt (intro at 4.5 m, "Hi there! I'm Princess Flurry!") and the beacon has faded by then; sent back to her post she is waiting again with the beacon on.

**2. Clouds no longer clip the mountain** (`js/ice.js`)
- **Why.** The 16 clouds drifted at fixed heights of 48 to 148 m and went straight through the summit (68 m), the ring of peaks (up to about 64 m) and the castle's towers (up to about 130 m).
- **Fix.** Each cloud now keeps its underside at least 14 m above the highest ground (or castle) under its footprint. Every cloud is measured at 17 points out to 42 m from its middle (two clouds per frame, so each is re-measured every few frames), rises quickly when something is ahead of it and sinks slowly once it is past, and a cloud that wraps round to the far side starts at the right height. The castle counts as a block 68 m above the summit across its whole area. Clouds over the lowlands stay low, so the castle still floats above some of them.
- **Checked.** Every cloud swept across the whole world (about 5400 steps each), measuring about 1.3 million points on the clouds' own surfaces against the ground: the closest any cloud gets to the ground or castle is 14.9 m, and no point is ever below it.

**3. The ice slide** (`js/ice_slide.js`, new; hooks in `unicorn.js`, `ice.js`, `ice_guides.js`, `realm.js`, `main.js`, `index.html`)
- **What it is.** A banked chute of glittering ice about 129 m long, from a glowing snowflake pad on the castle's south lip (local -8, -82), in long S-curves down the face of the mountain to the plaza's edge (10, 38), 62 m lower. It lies on the ground (every vertex follows the terrain, so nothing solid stands in anyone's way), with low rounded candy-striped lips (pink and lilac), glassy streaks and stars on the bed that shimmer as the texture scrolls, a lamp every 14 m, three sparkle gates (ice arches that ring and burst when you ride through) and soft snow pillows at the end. A big arch over the start has a sign: "ICE SLIDE" for riders arriving from the castle, "WHEEE!" on the back. The first time you come near, a toast explains it. Trees, crystals and grass keep out of a 7 m corridor on each side.
- **The ride.** Roll onto the pad and the unicorn is carried down on rails: whoosh, a sparkle burst and a toast ("Wheee! Ice slide! Steer with the arrow keys, hop with Space"). Gravity along the slope, air drag and a little ice friction give about 22 m/s at the fastest (gallop is 18, walking 10.5) and a ride of about 8 s; Down brakes, Left and Right steer inside the lips (up to 2.35 m from the middle), Space hops about 1.2 m, Shift pushes a little, and each gate adds a little speed. The unicorn flies in the stretched-out gliding pose, pitched along the slope, with a trail of sparkles and ice spray, a shimmer sound and a fanfare when it ends. The camera swings round behind her down the chute and the view widens 6 degrees. At the end the unicorn is released at the plaza's edge at up to 12 m/s with the ice friction having slowed it, and the climb starts over for the guides (a ride count is saved: `iceSlides`). A princess aboard stays aboard; friends nearby cheer.
- **How it is built.** `Unicorn.update` gained one branch: while `unicorn.rail.active` the rail (`UA.IceSlide.rail.step`) moves the unicorn (position, heading, speed, pitch, hop) and the walking, jumping, colliding and ledge code is skipped; the pose, hair, shadow and effects still run. `rail.surfaceY` puts the shadow on the ice, `rail.pitch` sets the body pitch, and the chase camera follows the rail's heading. The path is a Catmull-Rom spline through 13 control points, resampled every 1.5 m; the ground under it follows the terrain at every vertex of the ribbon (11 per cross-section), and `Ice.slideNear` keeps the forest out. The climb guides pause while you slide.
- **Checked** (headless Chromium): a ride with no steering (8 s, peak 22.6 m/s, ends on the plaza's edge, released at 10.5 m/s); steering right then left holds at 2.35 m from the middle (never off the chute) and the unicorn is always 0.1 to 0.6 m above the ice (never under it); a hop of 1.16 m; braking from 20.8 to 14 m/s in 2 s; all 3 gates fire; standing or walking across the chute does not start a ride; a second ride counts 2; being carried to the main world mid-ride lets go cleanly (no errors); a ride with Princess Flurry aboard (she stays aboard during and after the ride) and a night ride (count 2, no errors). Regression soak on the final build: 5 rounds of "climb with the guides (54 s each), say hi to Flurry, slide down, go home through the return portal" gave no console errors, 5 of 5 rides of 129 m at a peak of 22.5 m/s ending grounded at the plaza's edge, the climb pill hidden again after going home, and textures steady at 26 after the first round.

## Next ideas (in rough priority)
1. Check performance on the real target device (iPad), then chunk the instanced props so the GPU can cull them
2. A rider avatar for the player themselves on the saddle (the princess is the first rider), more gear (a hat from Twirl Top Hats, a wand from Wands and Wonders), mane/tail styles
3. More quests and mini-games (flower-picking race, bubble-pop, cloud hopping)
4. More biomes inside the one big landscape (crystal caves, beach, sky islands)
5. More creature species (hatching eggs, baby animals that grow)
6. Photo mode and a sticker book of creatures found
7. Townsfolk follow-ups: a friends-book page for the residents, repeatable mail runs, bedtime stories at the inn, kids who ask for a game of tag, rooftop treasure
8. Parked whimsical ideas: tea party with friends, sparkle-snow weather, hot air balloon rides, treasure maps
